# Quick Reference Card - CloudKampus Automation

## 🚀 Most Used Commands

### Running Tests
```bash
npm test                    # Run all tests (headless)
npm run test:headed         # Run with visible browser
npm run test:login          # Run login tests only
npm run test:debug          # Debug mode with Playwright Inspector
npm run test:ui             # Interactive UI mode
```

### View Reports
```bash
npm run report              # Open HTML report in browser
```

### Installation
```bash
npm install                 # Install dependencies
npm run install:browsers    # Install Playwright browsers
```

## 📁 Important Files

| File | Purpose |
|------|---------|
| `playwright.config.js` | Main configuration |
| `tests/login.spec.js` | Login test cases |
| `pages/LoginPage.js` | Login page object |
| `data/login-data.json` | Test data |
| `utils/logger.js` | Logging utility |

## 🎯 Test Case IDs

| ID | Description |
|----|-------------|
| CK_LOGIN_001 | Valid login |
| CK_LOGIN_002 | Logout & session |

## 🔧 Configuration Files

| File | Environment |
|------|-------------|
| `config/dev.config.js` | Development |
| `config/test.config.js` | Testing |

## 📊 Report Locations

| Type | Location |
|------|----------|
| HTML | `reports/html-report/index.html` |
| JSON | `reports/test-results.json` |
| JUnit | `reports/junit-report.xml` |

## 📝 Log Files

| Type | Location |
|------|----------|
| All logs | `logs/combined.log` |
| Errors only | `logs/error.log` |

## 🌐 Test URLs

| Page | URL |
|------|-----|
| Login | `/views/admin/login.php` |
| Dashboard | `/views/admin/dashboard.php` |

## 🔑 Test Credentials

```json
{
  "username": "ramya",
  "password": "Aspire#2025"
}
```

## 🎬 Browser Commands

```bash
# Single browser
npx playwright test --project=chromium
npx playwright test --project=firefox
npx playwright test --project=webkit

# Headed mode
npx playwright test --headed

# Debug mode
npx playwright test --debug

# Specific test file
npx playwright test tests/login.spec.js
```

## 🔍 Debugging

```bash
# Pause test execution
await page.pause();

# Console logs
console.log(await page.title());

# Take screenshot
await page.screenshot({ path: 'debug.png' });
```

## 📦 NPM Scripts

| Script | Command |
|--------|---------|
| `npm test` | Run all tests |
| `npm run test:headed` | Headed mode |
| `npm run test:debug` | Debug mode |
| `npm run test:ui` | UI mode |
| `npm run report` | View report |
| `npm run install:browsers` | Install browsers |

## 🔄 Git Commands

```bash
# Daily workflow
git checkout develop
git pull origin develop
git checkout -b feature/my-feature
# ... make changes ...
git add .
git commit -m "Add: My feature"
git push origin feature/my-feature
```

## 🎯 Jenkins

| Action | Method |
|--------|--------|
| Manual build | Build with Parameters |
| View logs | Console Output |
| View report | Playwright Test Report link |

## ⚡ Keyboard Shortcuts (UI Mode)

| Key | Action |
|-----|--------|
| `Space` | Run test |
| `P` | Pick locator |
| `R` | Reload |
| `C` | Clear |

## 🆘 Quick Help

```bash
# Playwright help
npx playwright --help

# Test help
npx playwright test --help

# Show reporters
npx playwright show-report --help
```

---

**Print this for your desk!**  
Updated: December 12, 2025
