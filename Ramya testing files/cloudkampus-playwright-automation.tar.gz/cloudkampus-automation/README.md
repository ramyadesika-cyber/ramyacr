# CloudKampus Playwright Automation Framework

## 📋 Overview

This is a comprehensive Playwright automation framework for CloudKampus application, following industry best practices and designed for scalability. 

**Phase 1 Focus:** Login Module (Critical Path Testing)

## 🏗️ Framework Architecture

```
cloudkampus-automation/
├── .github/workflows/      # GitHub Actions CI/CD
├── config/                 # Environment configurations
├── data/                   # Test data (JSON format)
├── pages/                  # Page Object Models (POM)
├── tests/                  # Test specifications
├── utils/                  # Utilities (logger, screenshot, helpers)
├── reports/                # Test execution reports
├── logs/                   # Application logs
└── screenshots/            # Failure screenshots
```

## ✨ Key Features

- ✅ **Page Object Model (POM)** design pattern
- ✅ **Layered architecture** (Data, Page Objects, Tests, Utils)
- ✅ **Winston logger** for detailed logging
- ✅ **Screenshot capture** on failures
- ✅ **Multiple browser support** (Chromium, Firefox, WebKit)
- ✅ **Multiple report formats** (HTML, JSON, JUnit)
- ✅ **CI/CD ready** (GitHub Actions + Jenkins)
- ✅ **Data-driven testing** support
- ✅ **Parallel execution** capability
- ✅ **Video recording** on failure

## 📦 Prerequisites

- Node.js (v16 or higher)
- npm (v8 or higher)
- Git

## 🚀 Installation & Setup

### Step 1: Clone the repository

```bash
git clone <repository-url>
cd cloudkampus-automation
```

### Step 2: Install dependencies

```bash
npm install
```

### Step 3: Install Playwright browsers

```bash
npm run install:browsers
```

This will install Chromium, Firefox, and WebKit browsers.

## 🎯 Running Tests

### Run all tests (default: headless mode)

```bash
npm test
```

### Run tests in headed mode (visible browser)

```bash
npm run test:headed
```

### Run specific test file

```bash
npm run test:login
```

### Run tests in debug mode

```bash
npm run test:debug
```

### Run tests in UI mode (interactive)

```bash
npm run test:ui
```

### Run tests on specific browser

```bash
# Chromium only
npx playwright test --project=chromium

# Firefox only
npx playwright test --project=firefox

# WebKit only  
npx playwright test --project=webkit
```

### Run tests in parallel

```bash
npx playwright test --workers=4
```

## 📊 View Reports

### View HTML report

```bash
npm run report
```

This will open the HTML report in your browser automatically.

### Report locations:
- HTML Report: `reports/html-report/index.html`
- JSON Report: `reports/test-results.json`
- JUnit Report: `reports/junit-report.xml`

## 📝 Test Data Management

Test data is stored in JSON format in the `data/` directory:

- `data/login-data.json` - Login test data
- `data/test-users.json` - User credentials

### Example:
```json
{
  "validUser": {
    "username": "ramya",
    "password": "Aspire#2025"
  }
}
```

## 📖 Writing New Tests

### 1. Create Page Object (if needed)

```javascript
// pages/NewPage.js
const BasePage = require('./BasePage');

class NewPage extends BasePage {
  constructor(page) {
    super(page);
    this.locators = {
      element1: 'selector1',
      element2: 'selector2'
    };
  }
  
  async performAction() {
    await this.click(this.locators.element1);
  }
}

module.exports = NewPage;
```

### 2. Create Test Spec

```javascript
// tests/new-feature.spec.js
const { test, expect } = require('@playwright/test');
const NewPage = require('../pages/NewPage');
const logger = require('../utils/logger');

test.describe('New Feature Tests', () => {
  test('TC001: Test description', async ({ page }) => {
    logger.testStart('TC001');
    
    const newPage = new NewPage(page);
    await newPage.navigate('/path');
    
    // Test steps
    
    logger.testEnd('TC001', 'PASS');
  });
});
```

## 🔧 Configuration

### Environment Configuration

Modify `playwright.config.js` for:
- Base URL
- Timeouts
- Browser settings
- Screenshot/video settings
- Parallel execution

### Environment-specific configs:
- `config/dev.config.js` - Development
- `config/test.config.js` - Testing
- `config/prod.config.js` - Production (if needed)

## 📊 Logging

Logs are automatically generated using Winston logger:

- `logs/error.log` - Error logs only
- `logs/combined.log` - All logs
- Console output - Real-time logs

### Log levels:
- `error` - Critical errors
- `warn` - Warnings
- `info` - General information
- `debug` - Detailed debug information

## 📸 Screenshots

Screenshots are automatically captured:
- ✅ On test failure (automatic)
- ✅ Manual capture using `await page.takeScreenshot()`

Location: `screenshots/`

## 🎬 Video Recording

Videos are recorded for failed tests:
- Location: `test-results/`
- Format: WebM
- Retention: Configurable in `playwright.config.js`

## 🔄 CI/CD Integration

### GitHub Actions

Workflow file: `.github/workflows/playwright.yml`

**Triggers:**
- Push to main/develop branch
- Pull requests
- Daily schedule (6 AM UTC)
- Manual trigger

**Matrix execution:** Tests run on Chromium, Firefox, and WebKit

### Jenkins

Pipeline file: `Jenkinsfile`

**Parameters:**
- `BROWSER`: chromium, firefox, webkit, all
- `TEST_SUITE`: all, login, dashboard, smoke

**To use in Jenkins:**
1. Create new Pipeline job
2. Point to repository
3. Use `Jenkinsfile`
4. Configure build parameters

### Running in Jenkins:

```bash
# From Jenkins UI
Build with Parameters > Select browser and suite > Build

# From command line (if Jenkins CLI configured)
java -jar jenkins-cli.jar build CloudKampus-Tests \
  -p BROWSER=chromium -p TEST_SUITE=login
```

## 📁 Project Structure Details

### `/pages` - Page Object Models
- `BasePage.js` - Common methods for all pages
- `LoginPage.js` - Login page specific methods
- Future: `DashboardPage.js`, `UserManagementPage.js`, etc.

### `/tests` - Test Specifications
- `login.spec.js` - Login module tests (Phase 1)
- Future: `dashboard.spec.js`, `user-management.spec.js`, etc.

### `/utils` - Utilities
- `logger.js` - Winston logger configuration
- `screenshot.js` - Screenshot helper
- `helpers.js` - Common helper functions

### `/data` - Test Data
- `login-data.json` - Login test data
- `test-users.json` - User credentials
- Future: More JSON files as needed

### `/config` - Configurations
- `dev.config.js` - Development environment
- `test.config.js` - Test environment
- `prod.config.js` - Production environment (if applicable)

## 🎯 Current Test Coverage (Phase 1)

| Test ID | Description | Status |
|---------|-------------|--------|
| CK_LOGIN_001 | Login with valid credentials | ✅ Implemented |
| CK_LOGIN_002 | Logout and session management | ✅ Implemented |

## 🗺️ Roadmap

### Phase 1: Login Module ✅ (Current)
- Critical path login testing
- Session management
- Framework foundation

### Phase 2: Dashboard (Next)
- Dashboard page validation
- Navigation testing
- Data integrity checks

### Phase 3: User Management
- CRUD operations for users
- Role management
- User table validations

### Phase 4: Course Management
- CRUD operations for courses
- Domain categorization
- Course table validations

### Phase 5: Public View & Non-Functional
- Public page testing
- Non-functional tests (page load, images, links)
- Responsive design testing

## 🐛 Troubleshooting

### Issue: Browsers not installing

```bash
# Clear cache and reinstall
npx playwright install --force
```

### Issue: Tests timing out

Increase timeout in `playwright.config.js`:
```javascript
timeout: 120 * 1000, // 2 minutes
```

### Issue: Element not found

1. Check selector in Page Object
2. Increase wait time
3. Use `page.pause()` to debug
4. Check if element requires scroll

### Issue: Logs not generating

Check permissions on `logs/` directory:
```bash
chmod -R 755 logs/
```

## 📚 Best Practices

1. **Follow POM pattern** - Keep locators in Page Objects
2. **Use descriptive names** - Test names should describe what they test
3. **Log important steps** - Use logger for better debugging
4. **Handle waits properly** - Use explicit waits, avoid hard waits
5. **Keep tests independent** - Each test should run standalone
6. **Use test data files** - Don't hardcode test data
7. **Clean up after tests** - Delete created test data
8. **Take screenshots** - Especially on failures
9. **Write reusable functions** - DRY principle
10. **Document your code** - Add comments for complex logic

## 🤝 Contributing

1. Create feature branch: `git checkout -b feature/new-test`
2. Write tests following framework patterns
3. Ensure all tests pass: `npm test`
4. Commit changes: `git commit -m "Add: New test suite"`
5. Push branch: `git push origin feature/new-test`
6. Create Pull Request

## 📞 Support

For issues or questions:
- Create GitHub issue
- Contact QA team
- Review documentation

## 📄 License

This project is proprietary to CloudKampus QA Team.

---

**Last Updated:** December 12, 2025  
**Framework Version:** 1.0.0  
**Maintained by:** QA Automation Team
