# 📋 STEP-BY-STEP EXECUTION GUIDE

## Complete Walkthrough for Running CloudKampus Automation

---

## 🎯 PART 1: LOCAL SETUP & EXECUTION

### ⚙️ Step 1: Verify Prerequisites (2 minutes)

Open terminal/command prompt:

```bash
# Check Node.js (Should be v16+)
node --version

# Check npm
npm --version

# Check Git
git --version
```

**If any command fails:**
- Install Node.js from: https://nodejs.org/
- Git from: https://git-scm.com/

---

### 📦 Step 2: Install Project Dependencies (3 minutes)

```bash
# Navigate to project directory
cd cloudkampus-automation

# Install all packages
npm install
```

**What's happening?**
- Installing Playwright test framework
- Installing Winston logger
- Installing Allure reporter
- Installing helper libraries

**Expected Output:**
```
added 245 packages, and audited 246 packages in 45s
```

---

### 🌐 Step 3: Install Playwright Browsers (2 minutes)

```bash
# Install Chromium (recommended for first run)
npx playwright install chromium

# OR install all browsers (Chrome, Firefox, Safari)
npx playwright install
```

**What's happening?**
- Downloads browser binaries
- Sets up browser drivers
- Configures browser dependencies

**Expected Output:**
```
Downloading Chromium 119.0.6045.9
Chromium 119.0.6045.9 downloaded successfully
```

---

### ▶️ Step 4: Run Your First Test (1 minute)

```bash
# Option A: Run all tests (headless)
npm test

# Option B: Run with browser visible (recommended for first time)
npm run test:headed

# Option C: Run only login tests
npm run test:login
```

**What's happening?**
- Opening login page
- Entering credentials
- Verifying login success
- Running logout tests
- Capturing logs and screenshots

**Expected Output:**
```
Running 5 tests using 1 worker

✓ CK_LOGIN_001: Should login successfully with valid credentials (2.5s)
✓ CK_LOGIN_002: Should logout successfully (3.1s)
✓ Should mask password input (0.8s)
✓ Data-driven: Login with multiple test data sets (4.2s)
✓ Should display all login form elements correctly (1.1s)

  5 passed (11.7s)
```

---

### 📊 Step 5: View Test Report (1 minute)

```bash
# Open HTML report in browser
npm run report
```

**What opens?**
- Beautiful HTML report with test results
- Pass/fail status for each test
- Execution time
- Screenshots (for failures)
- Detailed error messages

**Report Location:**
`test-results/html-report/index.html`

---

### 🔍 Step 6: Explore Generated Artifacts (2 minutes)

Check these folders after test execution:

```bash
# 1. Logs folder
ls -la logs/
# Files: test-execution.log, errors.log

# 2. Screenshots folder (if tests failed)
ls -la screenshots/
# Files: FAILED_testname_timestamp.png

# 3. Test results folder
ls -la test-results/
# Files: junit.xml, results.json, html-report/
```

---

## 🔄 PART 2: GIT VERSION CONTROL

### 📝 Step 7: Initialize Git Repository (2 minutes)

```bash
# Initialize Git in project folder
git init

# Check status
git status
```

**Expected Output:**
```
Initialized empty Git repository in /path/to/cloudkampus-automation/.git/
```

---

### ➕ Step 8: Stage and Commit Files (2 minutes)

```bash
# Stage all files
git add .

# Check what's staged
git status

# First commit
git commit -m "Initial commit: Playwright framework Sprint 1 - Login module complete"
```

**Expected Output:**
```
[main (root-commit) abc1234] Initial commit: Playwright framework Sprint 1 - Login module complete
 15 files changed, 1250 insertions(+)
```

---

### 🌐 Step 9: Push to GitHub (3 minutes)

**First, create GitHub repository:**
1. Go to https://github.com
2. Click "New Repository"
3. Name: `cloudkampus-automation`
4. Keep it Private
5. Don't initialize with README
6. Click "Create Repository"

**Then connect and push:**

```bash
# Add GitHub remote (replace with YOUR username)
git remote add origin https://github.com/YOUR_USERNAME/cloudkampus-automation.git

# Verify remote
git remote -v

# Push to GitHub
git branch -M main
git push -u origin main
```

**Enter GitHub credentials when prompted**

**Expected Output:**
```
Enumerating objects: 20, done.
Counting objects: 100% (20/20), done.
Writing objects: 100% (20/20), 45.23 KiB | 2.26 MiB/s, done.
To https://github.com/YOUR_USERNAME/cloudkampus-automation.git
 * [new branch]      main -> main
```

---

### ✅ Step 10: Verify on GitHub (1 minute)

1. Go to: `https://github.com/YOUR_USERNAME/cloudkampus-automation`
2. You should see all your files
3. Verify folder structure is visible
4. Check README.md displays properly

---

## 🏗️ PART 3: JENKINS CI/CD SETUP

### 🔌 Step 11: Configure Jenkins - Install Plugins (5 minutes)

1. Open Jenkins: `http://localhost:8080` (or your Jenkins URL)
2. **Login** with admin credentials
3. Go to: **Manage Jenkins** → **Manage Plugins**
4. Click **Available Plugins** tab
5. Search and install (check the box):
   - ✅ **NodeJS Plugin**
   - ✅ **Git Plugin**
   - ✅ **HTML Publisher Plugin**
   - ✅ **JUnit Plugin**
6. Click **Install without restart**
7. Wait for installation to complete

---

### ⚙️ Step 12: Configure NodeJS in Jenkins (3 minutes)

1. Go to: **Manage Jenkins** → **Global Tool Configuration**
2. Scroll to **NodeJS** section
3. Click **Add NodeJS**
4. Configure:
   - **Name**: `NodeJS-18`
   - **Install automatically**: ✅ Checked
   - **Version**: Select `NodeJS 18.x` or higher
5. Click **Save**

---

### 🎯 Step 13: Create Jenkins Pipeline Job (5 minutes)

1. Jenkins Dashboard → Click **New Item**
2. **Job Configuration:**
   - **Name**: `CloudKampus-Automation`
   - **Type**: Select **Pipeline**
   - Click **OK**

3. **General Settings:**
   - **Description**: `Automated testing for CloudKampus application`
   - **GitHub project** (optional): Enter your repo URL

4. **Build Triggers:**
   - ✅ **Poll SCM**: `H/15 * * * *` (checks every 15 mins)
   - OR ✅ **GitHub hook trigger** (for webhook)

5. **Pipeline Configuration:**
   - **Definition**: Select `Pipeline script from SCM`
   - **SCM**: Select `Git`
   - **Repository URL**: `https://github.com/YOUR_USERNAME/cloudkampus-automation.git`
   - **Credentials**: Add your GitHub credentials
   - **Branch Specifier**: `*/main`
   - **Script Path**: `Jenkinsfile`

6. Click **Save**

---

### ▶️ Step 14: Run First Build in Jenkins (5 minutes)

1. On job page, click **Build Now**
2. Watch the **Build History** (build #1 appears)
3. Click on **#1** to see build details
4. Click **Console Output** to see live logs

**What Jenkins is doing:**
```
Stage 1: Checkout          → Cloning from Git
Stage 2: Install           → npm install, browser setup
Stage 3: Run Tests         → Executing Playwright tests
Stage 4: Generate Report   → Creating HTML report
Stage 5: Publish Results   → Publishing artifacts
```

**Expected Duration:** 3-5 minutes for first build

---

### 📊 Step 15: View Results in Jenkins (2 minutes)

After build completes:

1. **Build Status:**
   - ☀️ Blue/Green = Success
   - 🌥️ Yellow = Unstable
   - ☁️ Red = Failed

2. **Test Report:**
   - Click on **Playwright Test Report**
   - See pass/fail statistics
   - Click on individual tests for details

3. **JUnit Results:**
   - Click on **Test Result**
   - See trends over time
   - View failure details

---

### 🔔 Step 16: Set Up Automated Triggers (Optional, 3 minutes)

**Option A: GitHub Webhook (Automatic builds on push)**

1. Go to GitHub repository → Settings → Webhooks
2. Click **Add webhook**
3. **Payload URL**: `http://YOUR_JENKINS_URL/github-webhook/`
4. **Content type**: `application/json`
5. **Events**: Select `Just the push event`
6. Click **Add webhook**

**Option B: Scheduled Builds**

Already configured with Poll SCM (`H/15 * * * *`)

---

## 🎓 PART 4: DAILY WORKFLOW

### 🔄 Step 17: Making Changes and Running Tests (Daily)

```bash
# 1. Pull latest changes from GitHub
git pull origin main

# 2. Make your code changes
# (Edit files in tests/, pages/, or config/)

# 3. Run tests locally first
npm test

# 4. If tests pass, commit and push
git add .
git commit -m "Added new test case for user registration"
git push origin main

# 5. Jenkins automatically picks up changes and runs tests
# (if webhook is configured, otherwise within 15 minutes)
```

---

### 📈 Step 18: Monitoring and Maintenance (Weekly)

**Weekly Tasks:**

1. **Check Test Trends:**
   - View Jenkins job dashboard
   - Look at test result trends
   - Identify flaky tests

2. **Review Logs:**
   ```bash
   # Check error logs
   cat logs/errors.log
   ```

3. **Update Dependencies:**
   ```bash
   # Update npm packages
   npm update
   
   # Update Playwright
   npx playwright install
   ```

4. **Clean Up:**
   ```bash
   # Remove old test results
   rm -rf test-results/*
   rm -rf screenshots/*
   rm -rf logs/*
   ```

---

## 🎯 VERIFICATION CHECKLIST

### ✅ Local Setup Complete
- [ ] Node.js installed and verified
- [ ] Project dependencies installed (`npm install`)
- [ ] Playwright browsers installed
- [ ] Tests run successfully locally
- [ ] HTML report generated and viewed

### ✅ Git Setup Complete
- [ ] Git repository initialized
- [ ] Files committed locally
- [ ] GitHub repository created
- [ ] Code pushed to GitHub
- [ ] Repository visible on GitHub

### ✅ Jenkins Setup Complete
- [ ] Jenkins plugins installed
- [ ] NodeJS configured in Jenkins
- [ ] Pipeline job created
- [ ] First build executed successfully
- [ ] Test report visible in Jenkins
- [ ] Automated trigger configured (optional)

---

## 🚨 COMMON ISSUES & SOLUTIONS

### Issue 1: npm install fails

```bash
# Clear cache and retry
npm cache clean --force
rm -rf node_modules package-lock.json
npm install
```

### Issue 2: Browsers not installing

```bash
# Install with dependencies
npx playwright install --with-deps chromium
```

### Issue 3: Tests timing out

Edit `playwright.config.js`:
```javascript
timeout: 60 * 1000,  // Increase to 60 seconds
```

### Issue 4: Jenkins build fails at npm install

- Check NodeJS is configured in Global Tool Configuration
- Verify Jenkins has internet access
- Check console output for specific error

### Issue 5: GitHub push authentication fails

```bash
# Use personal access token instead of password
# Generate token: GitHub → Settings → Developer settings → Personal access tokens
```

---

## 📞 SUPPORT

If you're stuck:

1. **Check logs:** `logs/test-execution.log`
2. **Check console output** in Jenkins
3. **Take screenshot** of error
4. **Check documentation:** `README.md`
5. **Contact:** QA Team

---

## 🎉 SUCCESS!

You've successfully:
✅ Set up local automation framework  
✅ Run tests locally  
✅ Pushed code to GitHub  
✅ Configured Jenkins CI/CD  
✅ Automated test execution  

**You're now ready for Sprint 2!** 🚀

---

**Next Sprint Preview:**
- Dashboard validation tests
- User management CRUD operations
- Course management tests
- API integration testing

**Happy Automating!** 🎯
