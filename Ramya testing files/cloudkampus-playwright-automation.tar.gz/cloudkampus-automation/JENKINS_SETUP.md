# Jenkins CI/CD Setup Guide

## 🎯 Objective
Configure Jenkins to run Playwright automation tests automatically.

## 📋 Prerequisites

- Jenkins server installed and running
- Node.js plugin installed in Jenkins
- Git plugin installed in Jenkins
- Jenkins user has access to repository

## 🔧 Step 1: Install Required Jenkins Plugins

1. Go to Jenkins Dashboard
2. Click "Manage Jenkins" > "Manage Plugins"
3. Install these plugins:
   - **NodeJS Plugin**
   - **Git Plugin**
   - **Pipeline Plugin**
   - **HTML Publisher Plugin**
   - **JUnit Plugin**
   - **Workspace Cleanup Plugin**

## 🛠️ Step 2: Configure Node.js in Jenkins

1. Go to "Manage Jenkins" > "Global Tool Configuration"
2. Scroll to "NodeJS"
3. Click "Add NodeJS"
4. Configure:
   - Name: `NodeJS-18`
   - Version: Select Node.js 18.x
   - Global npm packages: Leave empty
5. Click "Save"

## 📁 Step 3: Create Jenkins Pipeline Job

### Create New Item

1. Click "New Item" on Jenkins Dashboard
2. Enter name: `CloudKampus-Playwright-Tests`
3. Select "Pipeline"
4. Click "OK"

### Configure General Settings

1. **Description:** CloudKampus Automation Test Suite
2. **Discard old builds:** Keep last 30 builds
3. **GitHub project:** Enter repository URL (if using GitHub)

### Configure Build Triggers

Choose one or more:

- [x] **GitHub hook trigger** (for push events)
- [x] **Poll SCM:** `H/15 * * * *` (every 15 minutes)
- [x] **Build periodically:** `H 6 * * *` (daily at 6 AM)

### Pipeline Configuration

1. **Definition:** Pipeline script from SCM
2. **SCM:** Git
3. **Repository URL:** `<your-repo-url>`
4. **Credentials:** Add your Git credentials
5. **Branch:** `*/develop` or `*/main`
6. **Script Path:** `Jenkinsfile`

Click "Save"

## 📝 Step 4: Jenkinsfile Configuration

The Jenkinsfile is already created in the framework. It includes:

```groovy
- Checkout stage
- Setup (npm install)
- Browser installation
- Test execution
- Report generation
- Artifact archiving
```

## 🎛️ Step 5: Configure Build Parameters

The Jenkinsfile includes parameters:

### Browser Selection
- chromium
- firefox
- webkit
- all

### Test Suite Selection
- all tests
- login tests only
- dashboard tests only
- smoke tests

These appear automatically when you "Build with Parameters"

## 📊 Step 6: Configure Post-Build Actions

Already configured in Jenkinsfile:

1. **Archive Artifacts**
   - Test reports
   - Screenshots
   - Videos

2. **Publish JUnit Results**
   - Path: `reports/junit-report.xml`

3. **Publish HTML Reports**
   - Path: `reports/html-report`

## 🚀 Step 7: Run Your First Build

### Manual Trigger

1. Go to job page
2. Click "Build with Parameters"
3. Select:
   - BROWSER: chromium
   - TEST_SUITE: login
4. Click "Build"

### Monitor Build

1. Click on build number (e.g., #1)
2. Click "Console Output"
3. Watch real-time logs

## 📈 Step 8: View Results

### Test Results

1. After build completes
2. Click on build number
3. View:
   - **Test Result** - JUnit summary
   - **Playwright Test Report** - HTML report
   - **Artifacts** - Screenshots, videos

### Failed Tests

- Red = Failed
- Yellow = Unstable
- Blue = Success
- Grey = Aborted

## 🔔 Step 9: Setup Notifications (Optional)

### Email Notifications

1. Install "Email Extension Plugin"
2. Configure in Jenkinsfile:

```groovy
post {
    failure {
        emailext (
            subject: "Build Failed: ${env.JOB_NAME}",
            body: "Build ${env.BUILD_NUMBER} failed",
            to: "team@example.com"
        )
    }
}
```

### Slack Notifications

1. Install "Slack Notification Plugin"
2. Configure Slack workspace
3. Add to Jenkinsfile:

```groovy
post {
    always {
        slackSend (
            channel: '#qa-automation',
            message: "Build ${env.BUILD_STATUS}: ${env.JOB_NAME} #${env.BUILD_NUMBER}"
        )
    }
}
```

## 🔐 Step 10: Security Best Practices

### Credentials

1. Never hardcode passwords in Jenkinsfile
2. Use Jenkins Credentials:
   - Go to "Manage Jenkins" > "Manage Credentials"
   - Add credentials
   - Reference in Jenkinsfile:

```groovy
environment {
    LOGIN_CREDS = credentials('cloudkampus-creds')
}
```

### Branch Protection

1. Restrict who can trigger builds
2. Configure in "Configure" > "Build Triggers"
3. Add build authorization

## 🧪 Testing Jenkins Pipeline

### Local Testing

```bash
# Install Jenkins job builder (optional)
pip install jenkins-job-builder

# Validate Jenkinsfile syntax
curl -X POST -F "jenkinsfile=<Jenkinsfile" \
  http://jenkins-server/pipeline-model-converter/validate
```

### Debugging

Add debug statements in Jenkinsfile:

```groovy
stage('Debug') {
    steps {
        sh 'node --version'
        sh 'npm --version'
        sh 'ls -la'
        sh 'pwd'
    }
}
```

## 📊 Example Jenkins Dashboard

After successful setup, you'll see:

```
CloudKampus-Playwright-Tests
├── Last Build: #42 (Success) - 5 min ago
├── Success Rate: 95% (last 20 builds)
├── Test Results: 26 passed, 0 failed
└── Trend: Stable ✓
```

## 🔧 Troubleshooting

### Issue 1: "npm: command not found"

**Solution:**
```groovy
// Add to Jenkinsfile
tools {
    nodejs 'NodeJS-18'
}
```

### Issue 2: "Playwright browsers not found"

**Solution:**
```groovy
// Ensure browsers are installed
stage('Install Browsers') {
    steps {
        sh 'npx playwright install --with-deps'
    }
}
```

### Issue 3: Permission denied

**Solution:**
```bash
# On Jenkins server
sudo chown -R jenkins:jenkins /var/lib/jenkins/workspace
```

### Issue 4: Build hangs indefinitely

**Solution:**
```groovy
// Add timeout
options {
    timeout(time: 1, unit: 'HOURS')
}
```

## 📋 Maintenance Checklist

Weekly:
- [ ] Review failed builds
- [ ] Check disk space
- [ ] Clean old artifacts

Monthly:
- [ ] Update Jenkins plugins
- [ ] Review build times
- [ ] Optimize pipeline

## 🎯 Advanced Configuration

### Parallel Execution

```groovy
stage('Parallel Tests') {
    parallel {
        stage('Chrome') {
            steps {
                sh 'npx playwright test --project=chromium'
            }
        }
        stage('Firefox') {
            steps {
                sh 'npx playwright test --project=firefox'
            }
        }
    }
}
```

### Conditional Execution

```groovy
stage('Smoke Tests') {
    when {
        branch 'develop'
    }
    steps {
        sh 'npm run test:smoke'
    }
}
```

### Matrix Builds

```groovy
matrix {
    axes {
        axis {
            name 'BROWSER'
            values 'chromium', 'firefox', 'webkit'
        }
    }
    stages {
        stage('Test') {
            steps {
                sh "npx playwright test --project=${BROWSER}"
            }
        }
    }
}
```

## 📚 Additional Resources

- Jenkins Documentation: https://www.jenkins.io/doc/
- Pipeline Syntax: https://www.jenkins.io/doc/book/pipeline/syntax/
- Best Practices: https://www.jenkins.io/doc/book/pipeline/pipeline-best-practices/

---

**Setup Time:** ~30 minutes  
**Maintenance:** Minimal once configured  
**Support:** Contact DevOps/QA team

Last updated: December 12, 2025
