# ⚡ QUICK START GUIDE - CloudKampus Automation

## 🚀 Get Running in 5 Minutes!

### Step 1: Setup (One-time)

```bash
# Navigate to project folder
cd cloudkampus-automation

# Install dependencies
npm install

# Install browsers
npx playwright install chromium
```

### Step 2: Run Your First Test

```bash
# Run tests (headless mode)
npm test

# OR run with visible browser
npm run test:headed
```

### Step 3: View Results

```bash
# Open HTML report
npm run report
```

That's it! Your first automated test is running! 🎉

---

## 📝 Quick Commands Reference

```bash
# RUN TESTS
npm test                    # Run all tests (headless)
npm run test:login          # Run only login tests
npm run test:headed         # Run with browser visible
npm run test:debug          # Debug mode with inspector

# REPORTS
npm run report              # Open HTML report

# BROWSERS
npm run test:chromium       # Run in Chrome
npm run test:firefox        # Run in Firefox
npm run test:webkit         # Run in Safari
```

---

## 🎯 What Tests Are Included?

**Sprint 1: Login Module** ✅

1. ✅ **CK_LOGIN_001**: Valid login flow
2. ✅ **CK_LOGIN_002**: Logout & session management
3. ✅ Password masking verification
4. ✅ Data-driven tests with multiple datasets
5. ✅ UI element validation

**Total**: 5 automated test cases

---

## 📊 Understanding Results

After running tests, you'll see:

```
Running 5 tests using 1 worker

✓ CK_LOGIN_001: Should login successfully with valid credentials (2.5s)
✓ CK_LOGIN_002: Should logout successfully and prevent back button access (3.1s)
✓ Should mask password input (0.8s)
✓ Data-driven: Login with multiple test data sets (4.2s)
✓ Should display all login form elements correctly (1.1s)

5 passed (11.7s)
```

**Green ✓** = Test Passed  
**Red ✗** = Test Failed  

If any test fails:
1. Check `screenshots/` folder for failure screenshot
2. Check `logs/test-execution.log` for details
3. Open HTML report: `npm run report`

---

## 🔧 Quick Troubleshooting

### Problem: "Cannot find module '@playwright/test'"
**Solution**:
```bash
npm install
```

### Problem: "browserType.launch: Executable doesn't exist"
**Solution**:
```bash
npx playwright install
```

### Problem: Tests are too slow
**Solution**:
```bash
# Run tests in parallel
npx playwright test --workers=4
```

### Problem: Need to see what's happening
**Solution**:
```bash
# Run in headed mode
npm run test:headed

# OR debug mode
npm run test:debug
```

---

## 📂 Where Are My Files?

```
📁 cloudkampus-automation/
├── 📝 tests/login.spec.js      ← Your test cases
├── 🎭 pages/LoginPage.js       ← Page interactions
├── ⚙️ config/test-data.json    ← Test data
├── 📊 test-results/            ← Test reports
├── 📸 screenshots/             ← Failure screenshots
└── 📋 logs/                    ← Execution logs
```

---

## 🎓 Key Concepts (2-Minute Read)

### 1. Page Object Model (POM)
Instead of writing:
```javascript
await page.fill('#username', 'ramya');
await page.fill('#password', 'Aspire#2025');
await page.click('button[type="submit"]');
```

We write:
```javascript
await loginPage.login('ramya', 'Aspire#2025');
```

**Why?** Easier to maintain, reuse, and read!

### 2. Test Data Layer
Test data is in `config/test-data.json`, NOT in test files.

**Why?** Change data without touching code!

### 3. Logging
Every action is logged in `logs/test-execution.log`.

**Why?** Debug faster when tests fail!

---

## 🔄 Git Commands (Copy-Paste Ready)

```bash
# First time setup
git init
git add .
git commit -m "Initial commit: Sprint 1 - Login automation"

# Daily work
git status                           # Check what changed
git add .                            # Stage all changes
git commit -m "Added new test case"  # Commit changes
git push origin main                 # Push to GitHub

# Get latest code
git pull origin main
```

---

## 🏗️ Jenkins Setup (Quick Version)

1. **Jenkins Dashboard** → New Item
2. **Name**: CloudKampus-Automation
3. **Type**: Pipeline
4. **Pipeline**: 
   - Definition: Pipeline script from SCM
   - SCM: Git
   - Repository URL: `your-repo-url`
   - Script Path: `Jenkinsfile`
5. **Save** → **Build Now**

Done! Jenkins will now run your tests automatically.

---

## 💡 Pro Tips

1. **Run specific test**:
   ```bash
   npx playwright test -g "valid credentials"
   ```

2. **Run only failed tests**:
   ```bash
   npx playwright test --last-failed
   ```

3. **Generate trace for debugging**:
   ```bash
   npx playwright test --trace on
   npx playwright show-trace trace.zip
   ```

4. **Update browsers**:
   ```bash
   npx playwright install
   ```

5. **Check Playwright version**:
   ```bash
   npx playwright --version
   ```

---

## 🎯 Success Checklist

- [x] Installed Node.js
- [x] Ran `npm install`
- [x] Installed browsers
- [x] Ran first test
- [x] Viewed HTML report
- [ ] Pushed to Git
- [ ] Set up Jenkins (optional)

---

## 📞 Need Help?

1. Check logs: `logs/test-execution.log`
2. Check report: `npm run report`
3. Check screenshots: `screenshots/` folder
4. Read full guide: `README.md`

---

## 🎉 You're Ready!

You now have a working automation framework. Time to:
1. Run tests locally ✅
2. Push to Git ✅
3. Set up Jenkins CI/CD ✅
4. Start Sprint 2 (Dashboard tests) 🚀

**Happy Testing!** 🎯
