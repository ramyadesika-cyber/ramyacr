# Git Workflow Guide - CloudKampus Automation

## 📚 Purpose
Guidelines for version control and collaboration on the automation framework.

## 🌿 Branching Strategy

```
main
  ├── develop
  │   ├── feature/login-tests
  │   ├── feature/dashboard-tests
  │   └── feature/user-management
  └── hotfix/critical-bug
```

### Branch Types

1. **main** - Production-ready code
   - Always stable and deployable
   - Protected branch
   - Requires PR approval

2. **develop** - Integration branch
   - Latest development changes
   - Base for feature branches
   - Regularly merged to main

3. **feature/** - New features/tests
   - Created from develop
   - Naming: `feature/module-name`
   - Merged back to develop

4. **bugfix/** - Bug fixes
   - Created from develop
   - Naming: `bugfix/issue-description`
   - Merged back to develop

5. **hotfix/** - Critical production fixes
   - Created from main
   - Naming: `hotfix/critical-issue`
   - Merged to both main and develop

## 🔄 Workflow Steps

### 1. Starting New Work

```bash
# Update your local develop branch
git checkout develop
git pull origin develop

# Create feature branch
git checkout -b feature/login-enhancements

# Work on your changes...
```

### 2. Making Changes

```bash
# Stage your changes
git add .

# Commit with descriptive message
git commit -m "Add: Login validation test cases"

# Push to remote
git push origin feature/login-enhancements
```

### 3. Commit Message Format

Follow conventional commits:

```bash
# New feature
git commit -m "Add: New dashboard test suite"

# Bug fix
git commit -m "Fix: Login page locator issue"

# Update/Enhancement
git commit -m "Update: Improve error handling in BasePage"

# Documentation
git commit -m "Docs: Add API testing guide"

# Refactor
git commit -m "Refactor: Restructure page objects"

# Test changes
git commit -m "Test: Add negative test cases for login"
```

### 4. Creating Pull Request

```bash
# Push your branch
git push origin feature/login-enhancements

# On GitHub/GitLab:
# 1. Click "New Pull Request"
# 2. Select: base=develop, compare=feature/login-enhancements
# 3. Fill description
# 4. Assign reviewers
# 5. Create PR
```

### 5. Code Review

**Reviewer checklist:**
- [ ] Tests pass in CI/CD
- [ ] Code follows framework patterns
- [ ] Page Objects used correctly
- [ ] Test data externalized
- [ ] Proper logging added
- [ ] Documentation updated
- [ ] No hardcoded values

### 6. Merging

```bash
# After PR approval, merge via GitHub/GitLab UI

# OR locally:
git checkout develop
git merge --no-ff feature/login-enhancements
git push origin develop

# Delete feature branch
git branch -d feature/login-enhancements
git push origin --delete feature/login-enhancements
```

## 📋 Git Best Practices

### DO ✅

1. **Commit Often** - Small, focused commits
2. **Write Clear Messages** - Describe what and why
3. **Pull Before Push** - Stay updated
4. **Use Branches** - Never work directly on main/develop
5. **Review Before Commit** - Check your changes
6. **Run Tests** - Ensure tests pass before pushing
7. **Keep Branches Updated** - Regularly merge develop

### DON'T ❌

1. **Don't Commit Build Artifacts** - node_modules, reports
2. **Don't Commit Secrets** - passwords, API keys
3. **Don't Force Push** - Unless absolutely necessary
4. **Don't Commit Commented Code** - Remove or fix
5. **Don't Skip Tests** - Always run tests before commit
6. **Don't Create Huge PRs** - Keep them focused

## 🔧 Useful Git Commands

### Daily Commands

```bash
# Check status
git status

# View changes
git diff

# View commit history
git log --oneline --graph

# Switch branches
git checkout branch-name

# Create and switch to new branch
git checkout -b feature/new-feature
```

### Undo Changes

```bash
# Undo last commit (keep changes)
git reset --soft HEAD~1

# Undo changes in working directory
git checkout -- filename

# Discard all local changes
git reset --hard HEAD
```

### Stashing Changes

```bash
# Stash changes
git stash save "Work in progress"

# List stashes
git stash list

# Apply stash
git stash apply

# Apply and remove stash
git stash pop
```

### Updating Branch

```bash
# Update from develop while on feature branch
git checkout feature/my-feature
git merge develop

# OR use rebase (cleaner history)
git rebase develop
```

## 🎯 Initial Repository Setup

### First-time setup:

```bash
# Initialize repo
cd cloudkampus-automation
git init

# Create .gitignore (already provided)
# Stage all files
git add .

# Initial commit
git commit -m "Initial commit: Playwright framework setup"

# Add remote
git remote add origin <your-repo-url>

# Create branches
git checkout -b develop
git push -u origin develop

git checkout -b main
git push -u origin main

# Set develop as default
git checkout develop
```

### Protect Branches

On GitHub/GitLab:
1. Go to Settings > Branches
2. Protect `main` branch:
   - Require PR reviews (at least 1)
   - Require status checks (CI/CD)
   - No force push
3. Protect `develop` similarly

## 📊 Example Workflow

```bash
# Day 1: Start new feature
git checkout develop
git pull origin develop
git checkout -b feature/dashboard-tests
# ... write tests ...
git add tests/dashboard.spec.js
git commit -m "Add: Dashboard validation tests"
git push origin feature/dashboard-tests

# Day 2: Continue work
git pull origin develop  # Stay updated
# ... more work ...
git add .
git commit -m "Add: Dashboard navigation tests"
git push origin feature/dashboard-tests

# Day 3: Complete and merge
# Create PR on GitHub
# Review and approval
# Merge to develop
# CI/CD runs automatically
```

## 🚨 Emergency Procedures

### Accidentally committed to wrong branch

```bash
# Undo commit but keep changes
git reset --soft HEAD~1

# Switch to correct branch
git checkout correct-branch

# Commit again
git add .
git commit -m "Your message"
```

### Need to fix committed credentials

```bash
# Remove from history (DANGEROUS)
git filter-branch --force --index-filter \
  'git rm --cached --ignore-unmatch path/to/file' \
  --prune-empty --tag-name-filter cat -- --all

# Force push (only if branch not protected)
git push origin --force --all
```

## 📚 Additional Resources

- Git Documentation: https://git-scm.com/doc
- GitHub Flow: https://guides.github.com/introduction/flow/
- Conventional Commits: https://www.conventionalcommits.org/

---

**Remember:** Communication is key! Always discuss major changes with team before implementing.

Last updated: December 12, 2025
