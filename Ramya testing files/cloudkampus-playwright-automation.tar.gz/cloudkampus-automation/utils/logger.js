/**
 * Logger Utility using Winston
 * Provides structured logging with different levels
 */

const winston = require('winston');
const path = require('path');
const fs = require('fs');

// Create logs directory if it doesn't exist
const logsDir = path.join(__dirname, '../logs');
if (!fs.existsSync(logsDir)) {
  fs.mkdirSync(logsDir, { recursive: true });
}

// Define log format
const logFormat = winston.format.combine(
  winston.format.timestamp({ format: 'YYYY-MM-DD HH:mm:ss' }),
  winston.format.errors({ stack: true }),
  winston.format.splat(),
  winston.format.json()
);

// Create logger instance
const logger = winston.createLogger({
  level: process.env.LOG_LEVEL || 'info',
  format: logFormat,
  defaultMeta: { service: 'cloudkampus-automation' },
  transports: [
    // Error log file
    new winston.transports.File({ 
      filename: path.join(logsDir, 'error.log'), 
      level: 'error',
      maxsize: 5242880, // 5MB
      maxFiles: 5
    }),
    // Combined log file
    new winston.transports.File({ 
      filename: path.join(logsDir, 'combined.log'),
      maxsize: 5242880,
      maxFiles: 5
    }),
    // Console output with color
    new winston.transports.Console({
      format: winston.format.combine(
        winston.format.colorize(),
        winston.format.simple()
      )
    })
  ]
});

// Custom log methods
logger.testStart = (testName) => {
  logger.info(`TEST START: ${testName}`, { type: 'test-start' });
};

logger.testEnd = (testName, status) => {
  logger.info(`TEST END: ${testName} - Status: ${status}`, { 
    type: 'test-end', 
    status 
  });
};

logger.step = (stepDescription) => {
  logger.info(`STEP: ${stepDescription}`, { type: 'step' });
};

logger.assertion = (description, result) => {
  logger.info(`ASSERTION: ${description} - ${result ? 'PASS' : 'FAIL'}`, {
    type: 'assertion',
    result
  });
};

module.exports = logger;
