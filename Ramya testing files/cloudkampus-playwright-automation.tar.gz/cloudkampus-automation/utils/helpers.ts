import { Page } from '@playwright/test';
import logger from './logger';

/**
 * Helper utility functions for test automation
 */

/**
 * Wait for page to load completely
 * @param page - Playwright Page object
 * @param timeout - Maximum wait time in milliseconds
 */
export async function waitForPageLoad(page: Page, timeout: number = 30000): Promise<void> {
  try {
    await page.waitForLoadState('networkidle', { timeout });
    logger.info('Page loaded successfully');
  } catch (error) {
    logger.error('Page load timeout', error);
    throw error;
  }
}

/**
 * Take screenshot with custom name
 * @param page - Playwright Page object
 * @param name - Screenshot file name
 */
export async function takeScreenshot(page: Page, name: string): Promise<void> {
  const screenshotPath = `screenshots/${name}-${Date.now()}.png`;
  await page.screenshot({ path: screenshotPath, fullPage: true });
  logger.info(`Screenshot saved: ${screenshotPath}`);
}

/**
 * Get current timestamp for unique identifiers
 * @returns Formatted timestamp string
 */
export function getTimestamp(): string {
  return new Date().toISOString().replace(/[:.]/g, '-');
}

/**
 * Generate random string
 * @param length - Length of random string
 * @returns Random string
 */
export function generateRandomString(length: number = 8): string {
  return Math.random().toString(36).substring(2, length + 2);
}

/**
 * Wait for specified duration
 * @param ms - Milliseconds to wait
 */
export async function wait(ms: number): Promise<void> {
  return new Promise(resolve => setTimeout(resolve, ms));
}

/**
 * Retry function with exponential backoff
 * @param fn - Function to retry
 * @param maxRetries - Maximum number of retries
 * @param delay - Initial delay in milliseconds
 */
export async function retryWithBackoff<T>(
  fn: () => Promise<T>,
  maxRetries: number = 3,
  delay: number = 1000
): Promise<T> {
  for (let i = 0; i < maxRetries; i++) {
    try {
      return await fn();
    } catch (error) {
      if (i === maxRetries - 1) throw error;
      await wait(delay * Math.pow(2, i));
      logger.warn(`Retry attempt ${i + 1} of ${maxRetries}`);
    }
  }
  throw new Error('Max retries exceeded');
}

/**
 * Clear browser cache and cookies
 * @param page - Playwright Page object
 */
export async function clearBrowserData(page: Page): Promise<void> {
  const context = page.context();
  await context.clearCookies();
  logger.info('Browser data cleared');
}
