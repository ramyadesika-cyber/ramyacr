import fs from 'fs';
import path from 'path';
import logger from './logger';

/**
 * Test Data utility for loading JSON test data
 */

/**
 * Load JSON file from testdata directory
 * @param filename - Name of JSON file
 * @returns Parsed JSON object
 */
export function loadTestData(filename: string): any {
  try {
    const filePath = path.join(process.cwd(), 'testdata', filename);
    const data = fs.readFileSync(filePath, 'utf-8');
    logger.info(`Test data loaded: ${filename}`);
    return JSON.parse(data);
  } catch (error) {
    logger.error(`Error loading test data: ${filename}`, error);
    throw error;
  }
}

/**
 * Get user credentials from users.json
 * @param userType - Type of user (validUser, invalidUser, etc.)
 * @returns User credentials object
 */
export function getUserCredentials(userType: string = 'validUser'): any {
  const users = loadTestData('users.json');
  return users[userType];
}

/**
 * Get configuration for specific environment
 * @param env - Environment name (dev, test, prod)
 * @returns Configuration object
 */
export function getConfig(env: string = 'test'): any {
  const config = loadTestData('config.json');
  return config[env];
}

/**
 * Get test data from testdata.json
 * @param section - Section name in testdata.json
 * @returns Test data object
 */
export function getTestData(section: string): any {
  const testdata = loadTestData('testdata.json');
  return testdata[section];
}
