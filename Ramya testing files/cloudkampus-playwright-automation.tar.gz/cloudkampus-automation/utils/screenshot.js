/**
 * Screenshot Utility
 * Handles screenshot capture with naming conventions
 */

const path = require('path');
const fs = require('fs');

class ScreenshotHelper {
  constructor() {
    this.screenshotDir = path.join(__dirname, '../screenshots');
    this.ensureDirectoryExists();
  }

  ensureDirectoryExists() {
    if (!fs.existsSync(this.screenshotDir)) {
      fs.mkdirSync(this.screenshotDir, { recursive: true });
    }
  }

  generateFileName(testName, step) {
    const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
    const sanitizedTestName = testName.replace(/[^a-z0-9]/gi, '_');
    const sanitizedStep = step ? `_${step.replace(/[^a-z0-9]/gi, '_')}` : '';
    return `${sanitizedTestName}${sanitizedStep}_${timestamp}.png`;
  }

  async capture(page, testName, step = '') {
    const fileName = this.generateFileName(testName, step);
    const filePath = path.join(this.screenshotDir, fileName);
    
    await page.screenshot({ 
      path: filePath, 
      fullPage: true 
    });
    
    return filePath;
  }

  async captureOnFailure(page, testInfo) {
    const fileName = this.generateFileName(testInfo.title, 'FAILURE');
    const filePath = path.join(this.screenshotDir, fileName);
    
    await page.screenshot({ 
      path: filePath, 
      fullPage: true 
    });
    
    // Attach to test report
    await testInfo.attach('failure-screenshot', {
      path: filePath,
      contentType: 'image/png'
    });
    
    return filePath;
  }
}

module.exports = new ScreenshotHelper();
