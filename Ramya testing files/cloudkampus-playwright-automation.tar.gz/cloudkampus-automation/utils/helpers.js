/**
 * Helper Utilities
 * Common functions used across tests
 */

class Helpers {
  /**
   * Wait for element to be visible and ready
   */
  async waitForElement(page, selector, timeout = 10000) {
    await page.waitForSelector(selector, { 
      state: 'visible', 
      timeout 
    });
  }

  /**
   * Safe click with wait
   */
  async safeClick(page, selector, timeout = 10000) {
    await this.waitForElement(page, selector, timeout);
    await page.click(selector);
  }

  /**
   * Safe fill with wait
   */
  async safeFill(page, selector, text, timeout = 10000) {
    await this.waitForElement(page, selector, timeout);
    await page.fill(selector, text);
  }

  /**
   * Get current timestamp
   */
  getTimestamp() {
    return new Date().toISOString();
  }

  /**
   * Generate unique test data
   */
  generateUniqueId(prefix = 'test') {
    return `${prefix}_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
  }

  /**
   * Wait for page load
   */
  async waitForPageLoad(page, timeout = 30000) {
    await page.waitForLoadState('networkidle', { timeout });
  }

  /**
   * Check if element exists
   */
  async elementExists(page, selector) {
    try {
      await page.waitForSelector(selector, { timeout: 5000 });
      return true;
    } catch {
      return false;
    }
  }

  /**
   * Get element text
   */
  async getElementText(page, selector) {
    await this.waitForElement(page, selector);
    return await page.textContent(selector);
  }
}

module.exports = new Helpers();
