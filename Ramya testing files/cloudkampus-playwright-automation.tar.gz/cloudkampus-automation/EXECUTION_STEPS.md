# Step-by-Step Execution Guide 🎯

## Complete Guide to Run CloudKampus Automation Framework

### 📋 Table of Contents
1. [Initial Setup](#initial-setup)
2. [Running Tests Locally](#running-tests-locally)
3. [Setting up Git Repository](#setting-up-git-repository)
4. [Jenkins Configuration](#jenkins-configuration)
5. [Verification & Troubleshooting](#verification)

---

## 1️⃣ Initial Setup (One-Time)

### Prerequisites Installation

#### Windows:
```cmd
:: Download and install Node.js from https://nodejs.org/
:: Download and install Git from https://git-scm.com/

:: Verify installation
node --version
npm --version
git --version
```

#### Mac:
```bash
# Install Homebrew (if not installed)
/bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"

# Install Node.js and Git
brew install node
brew install git

# Verify
node --version
npm --version
git --version
```

#### Linux (Ubuntu/Debian):
```bash
# Update package list
sudo apt update

# Install Node.js
curl -fsSL https://deb.nodesource.com/setup_18.x | sudo -E bash -
sudo apt install -y nodejs

# Install Git
sudo apt install -y git

# Verify
node --version
npm --version
git --version
```

### Framework Installation

```bash
# Navigate to framework directory
cd cloudkampus-automation

# Install dependencies
npm install

# Expected output: 
# ✓ Packages installed successfully
# Check node_modules folder exists

# Install Playwright browsers (this takes 2-3 minutes)
npm run install:browsers

# Expected output:
# Downloading Chromium...
# Downloading Firefox...
# Downloading WebKit...
# ✓ All browsers installed
```

### Verify Installation

```bash
# Check Playwright version
npx playwright --version
# Should show: Version 1.40.0 or higher

# List installed browsers
npx playwright list-browsers
# Should show: Chromium, Firefox, WebKit with versions
```

---

## 2️⃣ Running Tests Locally

### Method 1: NPM Scripts (Recommended)

```bash
# Run ALL tests in headless mode (fastest)
npm test

# Expected output:
# Running 2 tests using 1 worker
# ✓ tests/login.spec.js:25:3 › CK_LOGIN_001 (5s)
# ✓ tests/login.spec.js:67:3 › CK_LOGIN_002 (8s)
# 2 passed (13s)
```

```bash
# Run tests with VISIBLE browser (for debugging)
npm run test:headed

# You'll see:
# - Browser window opening
# - Tests executing step-by-step
# - Real-time test actions
```

```bash
# Run SPECIFIC test file only
npm run test:login

# Runs only: tests/login.spec.js
```

```bash
# Run in DEBUG mode (step through tests)
npm run test:debug

# Opens Playwright Inspector
# Features:
# - Step through each action
# - Pick locators
# - View console logs
# - Take screenshots
```

```bash
# Run in UI MODE (interactive, best for development)
npm run test:ui

# Opens browser UI showing:
# - All test files
# - Test execution timeline
# - Locator picking
# - Video recording
```

### Method 2: Direct Playwright Commands

```bash
# Run on SPECIFIC browser only
npx playwright test --project=chromium    # Chrome
npx playwright test --project=firefox     # Firefox
npx playwright test --project=webkit      # Safari

# Run SPECIFIC test case by name
npx playwright test -g "CK_LOGIN_001"

# Run tests matching pattern
npx playwright test -g "login"

# Run with PARALLEL workers (faster)
npx playwright test --workers=4

# Run with RETRIES (for flaky tests)
npx playwright test --retries=2

# Run and keep browser OPEN on failure
npx playwright test --headed --debug
```

### View Test Reports

```bash
# After ANY test run, view HTML report
npm run report

# This will:
# 1. Generate report from test results
# 2. Open browser automatically
# 3. Show detailed test results

# Report includes:
# - Test summary (passed/failed)
# - Execution timeline
# - Screenshots on failure
# - Video recordings
# - Error stack traces
```

### Understanding Test Output

```bash
# Successful test output:
✓ CK_LOGIN_001: Login with valid credentials (5.2s)
  ✓ Step 1: Navigate to login page
  ✓ Step 2: Enter credentials
  ✓ Step 3: Click login
  ✓ Step 4: Verify dashboard

# Failed test output:
✗ CK_LOGIN_002: Logout test (3.8s)
  ✓ Step 1: Login
  ✗ Step 2: Click logout
     Error: Locator 'a:has-text("Logout")' not found
     
# Logs location: logs/combined.log
# Screenshots: screenshots/
# Videos: test-results/
```

---

## 3️⃣ Setting up Git Repository

### First Time Setup

```bash
# Navigate to framework root
cd cloudkampus-automation

# Initialize Git (if not already done)
git init

# Check what files will be committed
git status

# Should show:
# - All framework files
# - NOT showing: node_modules, reports, logs (excluded by .gitignore)

# Stage all files
git add .

# Verify staging
git status

# Should show files in green (ready to commit)

# Create initial commit
git commit -m "Initial commit: CloudKampus Playwright Framework - Phase 1"

# Create GitHub repository (via GitHub website)
# 1. Go to github.com
# 2. Click "New Repository"
# 3. Name: cloudkampus-automation
# 4. Description: Playwright automation framework
# 5. Private repository
# 6. DO NOT initialize with README (we have one)
# 7. Click "Create"

# Link local repo to GitHub
git remote add origin https://github.com/YOUR_USERNAME/cloudkampus-automation.git

# Create and push main branch
git branch -M main
git push -u origin main

# Create develop branch
git checkout -b develop
git push -u origin develop

# Set develop as default working branch
git checkout develop
```

### Daily Workflow

```bash
# Start of day: Update your branch
git checkout develop
git pull origin develop

# Create feature branch for new work
git checkout -b feature/dashboard-tests

# Make your changes...
# Edit files, write tests

# Check what changed
git status
git diff

# Stage your changes
git add tests/dashboard.spec.js
git add pages/DashboardPage.js

# OR stage everything
git add .

# Commit with descriptive message
git commit -m "Add: Dashboard validation test cases"

# Push to remote
git push origin feature/dashboard-tests

# On GitHub: Create Pull Request
# 1. Go to repository
# 2. Click "Pull Requests"
# 3. Click "New Pull Request"
# 4. Base: develop, Compare: feature/dashboard-tests
# 5. Fill description
# 6. Click "Create Pull Request"

# After review and approval: Merge via GitHub UI

# Cleanup: Delete local branch
git checkout develop
git pull origin develop
git branch -d feature/dashboard-tests
```

---

## 4️⃣ Jenkins Configuration

### Step 1: Access Jenkins

```
Open browser: http://your-jenkins-server:8080
Login with credentials
```

### Step 2: Install Required Plugins

```
1. Dashboard → Manage Jenkins → Manage Plugins
2. Click "Available" tab
3. Search and install:
   ☐ NodeJS Plugin
   ☐ Git Plugin  
   ☐ Pipeline Plugin
   ☐ HTML Publisher
   ☐ JUnit Plugin
4. Click "Install without restart"
5. Wait for installation
6. Check "Restart Jenkins when no jobs running"
```

### Step 3: Configure NodeJS

```
1. Manage Jenkins → Global Tool Configuration
2. Scroll to "NodeJS"
3. Click "Add NodeJS"
4. Configuration:
   Name: NodeJS-18
   Version: NodeJS 18.x
5. Click "Save"
```

### Step 4: Create Pipeline Job

```
1. Dashboard → New Item
2. Enter name: CloudKampus-Playwright-Tests
3. Select: Pipeline
4. Click "OK"

5. General Section:
   Description: CloudKampus automation test suite
   ☑ GitHub project: https://github.com/YOUR_USERNAME/cloudkampus-automation

6. Build Triggers:
   ☑ GitHub hook trigger
   ☑ Poll SCM: H/15 * * * * (every 15 min)
   ☑ Build periodically: H 6 * * * (daily 6 AM)

7. Pipeline Section:
   Definition: Pipeline script from SCM
   SCM: Git
   Repository URL: https://github.com/YOUR_USERNAME/cloudkampus-automation.git
   Credentials: Add → Username with password → Your GitHub credentials
   Branch: */develop
   Script Path: Jenkinsfile

8. Click "Save"
```

### Step 5: Run First Build

```
1. On job page, click "Build with Parameters"
2. Select:
   BROWSER: chromium
   TEST_SUITE: login
3. Click "Build"
4. Click build number (e.g., #1)
5. Click "Console Output"
6. Watch execution in real-time
7. After completion, view:
   - Test Result (JUnit summary)
   - Playwright Test Report (HTML)
   - Archived artifacts
```

### Automated Triggers

Once configured, Jenkins will automatically run:

```
✓ On every push to develop branch (via GitHub webhook)
✓ Every 15 minutes if changes detected
✓ Daily at 6 AM regardless of changes
✓ On manual trigger: "Build with Parameters"
```

---

## 5️⃣ Verification & Troubleshooting

### Verify Everything Works

#### 1. Local Execution ✓

```bash
cd cloudkampus-automation

# Run tests
npm test

# Expected: All tests pass
# ✓ 2 passed (13s)

# View report
npm run report

# Expected: Report opens in browser
```

#### 2. File Structure ✓

```bash
# Verify directory structure
ls -la

# Should see:
# ✓ node_modules/
# ✓ pages/
# ✓ tests/  
# ✓ utils/
# ✓ config/
# ✓ data/
# ✓ package.json
# ✓ playwright.config.js
# ✓ Jenkinsfile
# ✓ README.md
```

#### 3. Git Repository ✓

```bash
# Check remote
git remote -v

# Should show GitHub URLs

# Check branches
git branch -a

# Should show:
# * develop
#   main
#   remotes/origin/develop
#   remotes/origin/main
```

#### 4. Jenkins Pipeline ✓

```
1. Go to Jenkins job
2. Check "Build History"
3. Should see: 
   ☑ At least 1 successful build (blue)
4. Click latest build
5. Verify:
   ☑ Test Result shows 2 passed
   ☑ Playwright Report available
   ☑ No errors in console
```

### Common Issues & Solutions

#### Issue 1: Tests fail locally

```bash
# Check Node version
node --version
# Must be 16+ 

# Reinstall dependencies
rm -rf node_modules
npm install

# Reinstall browsers
npx playwright install --force

# Run again
npm test
```

#### Issue 2: Jenkins build fails

```
Error: "npm: command not found"

Solution:
1. Manage Jenkins → Global Tool Configuration
2. Configure NodeJS correctly
3. In Jenkinsfile, add:
   tools {
       nodejs 'NodeJS-18'
   }
```

```
Error: "Playwright browsers not found"

Solution:
- Jenkins must run browser installation
- Check Jenkinsfile has:
  npx playwright install --with-deps
```

#### Issue 3: Git push rejected

```bash
# Pull latest changes first
git pull origin develop

# If conflicts, resolve manually
git status  # Check conflicted files
# Edit files, remove conflict markers
git add .
git commit -m "Resolve merge conflicts"
git push origin develop
```

#### Issue 4: Report not generating

```bash
# Check reports directory exists
ls -la reports/

# Run tests with explicit reporter
npx playwright test --reporter=html

# View report
npx playwright show-report
```

### Performance Checklist

- [ ] Tests complete in <2 minutes locally
- [ ] Jenkins build completes in <5 minutes
- [ ] No flaky tests (consistent pass/fail)
- [ ] Screenshots captured on failure
- [ ] Logs are readable and helpful
- [ ] Reports show all test details

---

## 🎉 Success Criteria

Your framework is ready when:

✅ Tests run successfully locally  
✅ Tests run in all 3 browsers (Chromium, Firefox, WebKit)  
✅ Git repository is set up with branches  
✅ Jenkins runs tests automatically  
✅ Reports are generated and viewable  
✅ Team members can clone and run tests  

---

## 📞 Getting Help

**Local Issues:** Check logs/combined.log  
**Jenkins Issues:** Check Console Output  
**Git Issues:** Run `git status` and read carefully  
**Framework Questions:** Review README.md  

**Contact:** QA Team Lead

---

**Estimated Setup Time:**
- Initial setup: 30 minutes
- Git configuration: 15 minutes  
- Jenkins configuration: 30 minutes
- **Total: ~75 minutes for complete setup**

**Last Updated:** December 12, 2025  
**Framework Version:** 1.0.0 - Phase 1 (Login Module)
