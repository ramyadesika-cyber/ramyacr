# ⚡ Quick Command Reference

## Installation & Setup
```bash
# Install dependencies
npm install

# Install browsers
npx playwright install

# Verify installation
npx playwright test --list
```

## Running Tests
```bash
# Run all tests
npm test

# Run with browser visible
npm run test:headed

# Run in debug mode
npm run test:debug

# Run in UI mode (interactive)
npm run test:ui

# Run specific browser
npm run test:chromium
npm run test:firefox
npm run test:webkit

# Run specific test file
npm run test:login
```

## Viewing Reports
```bash
# Open HTML report
npm run report

# Generate Allure report
npm run allure:generate
npm run allure:open
```

## Git Commands
```bash
# Initial setup
git init
git add .
git commit -m "Initial commit"
git remote add origin <url>
git push -u origin main

# Daily workflow
git pull origin main
git checkout -b feature/new-feature
git add .
git commit -m "Description"
git push origin feature/new-feature

# Check status
git status
git log --oneline

# View differences
git diff
```

## Debugging
```bash
# Run single test in debug mode
npx playwright test tests/login.spec.ts --debug

# Run with traces
npx playwright test --trace on

# View trace file
npx playwright show-trace trace.zip

# Generate codegen
npx playwright codegen https://learntest.xdemo.in
```

## Project Maintenance
```bash
# Update dependencies
npm update

# Update Playwright
npm install -D @playwright/test@latest

# Clean and reinstall
rm -rf node_modules package-lock.json
npm install

# Check for outdated packages
npm outdated
```

## Jenkins
```bash
# Test Jenkins pipeline locally (if using Jenkins CLI)
jenkins-cli build CloudKampus-Automation

# View last build log
jenkins-cli console CloudKampus-Automation
```

## Useful Playwright Commands
```bash
# List all tests
npx playwright test --list

# Run tests matching pattern
npx playwright test -g "login"

# Run tests in specific project
npx playwright test --project=chromium

# Show browser
npx playwright test --headed

# Run with workers
npx playwright test --workers=4

# Record video
npx playwright test --video=on

# Take screenshots
npx playwright test --screenshot=on
```

## Configuration
```bash
# Use different config file
npx playwright test --config=playwright.prod.config.ts

# Set base URL
npx playwright test --base-url=https://different-url.com

# Set timeout
npx playwright test --timeout=60000

# Set retries
npx playwright test --retries=2
```

## Reporting
```bash
# Different reporters
npx playwright test --reporter=dot
npx playwright test --reporter=list
npx playwright test --reporter=json
npx playwright test --reporter=junit
npx playwright test --reporter=html
```

## VS Code Integration
```bash
# Install Playwright extension
code --install-extension ms-playwright.playwright

# Open project in VS Code
code .
```

## Tips & Tricks
```bash
# Run only failed tests
npx playwright test --last-failed

# Run tests with specific tag
npx playwright test --grep @smoke

# Run tests without tag
npx playwright test --grep-invert @slow

# Parallel execution
npx playwright test --workers=50%

# Update snapshots
npx playwright test --update-snapshots
```
