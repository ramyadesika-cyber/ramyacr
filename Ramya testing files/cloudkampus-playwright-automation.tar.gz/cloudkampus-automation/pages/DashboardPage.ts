import { Page, Locator } from '@playwright/test';
import { BasePage } from './BasePage';
import logger from '../utils/logger';

/**
 * Dashboard Page Object Model
 * Contains all elements and methods for Dashboard page
 */
export class DashboardPage extends BasePage {
  // Locators
  readonly dashboardTitle: Locator;
  readonly logoutButton: Locator;
  readonly userProfile: Locator;
  readonly navigationMenu: Locator;
  readonly dashboardCards: Locator;
  readonly manageUsersCard: Locator;
  readonly manageCoursesCard: Locator;

  constructor(page: Page) {
    super(page);
    
    // Initialize locators
    this.dashboardTitle = page.locator('h1:has-text("Dashboard"), h2:has-text("Dashboard"), [class*="dashboard-title"]');
    this.logoutButton = page.locator('a:has-text("Logout"), button:has-text("Logout"), [href*="logout"]');
    this.userProfile = page.locator('.user-profile, [class*="profile"], [class*="user-info"]');
    this.navigationMenu = page.locator('.sidebar, .nav, [class*="navigation"]');
    this.dashboardCards = page.locator('.card, [class*="dashboard-card"], [class*="widget"]');
    this.manageUsersCard = page.locator('text="Manage Users"').first();
    this.manageCoursesCard = page.locator('text="Manage Courses"').first();
  }

  /**
   * Verify dashboard is loaded
   * @returns True if dashboard loaded
   */
  async isDashboardLoaded(): Promise<boolean> {
    try {
      await this.waitForElement(this.dashboardTitle, 10000);
      const url = await this.getCurrentUrl();
      const isDashboardUrl = url.includes('dashboard.php');
      logger.info(`Dashboard loaded: ${isDashboardUrl}`);
      return isDashboardUrl;
    } catch (error) {
      logger.error('Dashboard failed to load', error);
      return false;
    }
  }

  /**
   * Get dashboard title
   * @returns Dashboard title text
   */
  async getDashboardTitle(): Promise<string> {
    return await this.getText(this.dashboardTitle);
  }

  /**
   * Click logout button
   */
  async logout(): Promise<void> {
    logger.info('Clicking logout button');
    await this.click(this.logoutButton);
  }

  /**
   * Count dashboard cards
   * @returns Number of dashboard cards
   */
  async getDashboardCardsCount(): Promise<number> {
    const count = await this.dashboardCards.count();
    logger.info(`Dashboard cards count: ${count}`);
    return count;
  }

  /**
   * Check if navigation menu is visible
   * @returns True if menu visible
   */
  async isNavigationMenuVisible(): Promise<boolean> {
    return await this.isVisible(this.navigationMenu);
  }

  /**
   * Navigate to Manage Users
   */
  async navigateToManageUsers(): Promise<void> {
    logger.info('Navigating to Manage Users');
    await this.click(this.manageUsersCard);
  }

  /**
   * Navigate to Manage Courses
   */
  async navigateToManageCourses(): Promise<void> {
    logger.info('Navigating to Manage Courses');
    await this.click(this.manageCoursesCard);
  }

  /**
   * Verify user is logged in
   * @returns True if user profile visible
   */
  async isUserLoggedIn(): Promise<boolean> {
    return await this.isVisible(this.userProfile);
  }
}
