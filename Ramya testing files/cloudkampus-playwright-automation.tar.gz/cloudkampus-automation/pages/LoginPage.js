/**
 * Login Page Object Model
 * Contains all locators and methods for Login page
 */

const BasePage = require('./BasePage');
const logger = require('../utils/logger');

class LoginPage extends BasePage {
  constructor(page) {
    super(page);
    
    // Locators - Organized by section
    this.locators = {
      // Login form elements
      usernameInput: 'input[name="username"]',
      passwordInput: 'input[name="password"]',
      loginButton: 'button[type="submit"]',
      
      // Error messages
      errorMessage: '.error-message, .alert-danger',
      
      // Page elements
      pageTitle: 'h1, .login-title',
      formContainer: '.login-form, form',
      
      // Success indicators
      dashboardIndicator: '.dashboard, #dashboard',
      welcomeMessage: '.welcome-message',
      userProfile: '.user-profile, .user-info'
    };
    
    // URLs
    this.urls = {
      login: '/views/admin/login.php',
      dashboard: '/views/admin/dashboard.php'
    };
  }

  /**
   * Navigate to login page
   */
  async navigateToLogin() {
    logger.step('Navigating to Login page');
    const baseUrl = this.page.context()._options.baseURL || 'https://learntest.xdemo.in';
    await this.navigate(`${baseUrl}${this.urls.login}`);
  }

  /**
   * Check if on login page
   */
  async isOnLoginPage() {
    return await this.urlContains('login.php');
  }

  /**
   * Enter username
   */
  async enterUsername(username) {
    await this.fill(this.locators.usernameInput, username, 'Username field');
  }

  /**
   * Enter password
   */
  async enterPassword(password) {
    await this.fill(this.locators.passwordInput, password, 'Password field');
  }

  /**
   * Click login button
   */
  async clickLoginButton() {
    await this.click(this.locators.loginButton, 'Login button');
  }

  /**
   * Complete login flow
   */
  async login(username, password) {
    logger.step(`Attempting login with username: ${username}`);
    
    await this.enterUsername(username);
    await this.enterPassword(password);
    await this.clickLoginButton();
    
    // Wait for navigation
    await this.waitForNavigation();
  }

  /**
   * Verify successful login
   */
  async verifySuccessfulLogin() {
    logger.step('Verifying successful login');
    
    // Check URL changed to dashboard
    const onDashboard = await this.urlContains('dashboard.php');
    logger.assertion('Redirected to dashboard', onDashboard);
    
    // Verify dashboard elements visible
    const dashboardVisible = await this.isVisible(
      this.locators.dashboardIndicator, 
      10000
    );
    logger.assertion('Dashboard elements visible', dashboardVisible);
    
    return onDashboard && dashboardVisible;
  }

  /**
   * Verify login failure
   */
  async verifyLoginFailure() {
    logger.step('Verifying login failure');
    
    // Should still be on login page
    const onLoginPage = await this.isOnLoginPage();
    logger.assertion('Still on login page', onLoginPage);
    
    // Error message should be visible
    const errorVisible = await this.isVisible(this.locators.errorMessage, 5000);
    logger.assertion('Error message displayed', errorVisible);
    
    return onLoginPage && errorVisible;
  }

  /**
   * Get error message text
   */
  async getErrorMessage() {
    if (await this.isVisible(this.locators.errorMessage)) {
      return await this.getText(this.locators.errorMessage);
    }
    return null;
  }

  /**
   * Verify login form is displayed
   */
  async verifyLoginFormDisplayed() {
    logger.step('Verifying login form is displayed');
    
    const usernameVisible = await this.isVisible(this.locators.usernameInput);
    const passwordVisible = await this.isVisible(this.locators.passwordInput);
    const loginButtonVisible = await this.isVisible(this.locators.loginButton);
    
    logger.assertion('Username field visible', usernameVisible);
    logger.assertion('Password field visible', passwordVisible);
    logger.assertion('Login button visible', loginButtonVisible);
    
    return usernameVisible && passwordVisible && loginButtonVisible;
  }

  /**
   * Clear login form
   */
  async clearLoginForm() {
    await this.page.fill(this.locators.usernameInput, '');
    await this.page.fill(this.locators.passwordInput, '');
  }

  /**
   * Check if password is masked
   */
  async isPasswordMasked() {
    const passwordType = await this.page.getAttribute(
      this.locators.passwordInput, 
      'type'
    );
    return passwordType === 'password';
  }

  /**
   * Verify page title
   */
  async verifyPageTitle(expectedTitle) {
    const title = await this.getTitle();
    logger.assertion(`Page title contains "${expectedTitle}"`, 
                     title.includes(expectedTitle));
    return title.includes(expectedTitle);
  }
}

module.exports = LoginPage;
