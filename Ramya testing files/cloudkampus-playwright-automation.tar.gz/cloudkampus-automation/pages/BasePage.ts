import { Page, Locator } from '@playwright/test';
import logger from '../utils/logger';
import { waitForPageLoad, takeScreenshot } from '../utils/helpers';

/**
 * Base Page class
 * Contains common methods used across all page objects
 */
export class BasePage {
  readonly page: Page;

  constructor(page: Page) {
    this.page = page;
  }

  /**
   * Navigate to a URL
   * @param url - URL to navigate to
   */
  async navigateTo(url: string): Promise<void> {
    logger.info(`Navigating to: ${url}`);
    await this.page.goto(url);
    await waitForPageLoad(this.page);
  }

  /**
   * Click on an element
   * @param locator - Element locator
   */
  async click(locator: Locator): Promise<void> {
    await locator.waitFor({ state: 'visible' });
    await locator.click();
    logger.info(`Clicked on element: ${locator}`);
  }

  /**
   * Fill input field
   * @param locator - Input field locator
   * @param text - Text to fill
   */
  async fill(locator: Locator, text: string): Promise<void> {
    await locator.waitFor({ state: 'visible' });
    await locator.fill(text);
    logger.info(`Filled text in element: ${locator}`);
  }

  /**
   * Get text from element
   * @param locator - Element locator
   * @returns Element text content
   */
  async getText(locator: Locator): Promise<string> {
    await locator.waitFor({ state: 'visible' });
    const text = await locator.textContent() || '';
    logger.info(`Got text from element: ${text}`);
    return text;
  }

  /**
   * Check if element is visible
   * @param locator - Element locator
   * @returns True if visible, false otherwise
   */
  async isVisible(locator: Locator): Promise<boolean> {
    try {
      await locator.waitFor({ state: 'visible', timeout: 5000 });
      return true;
    } catch {
      return false;
    }
  }

  /**
   * Wait for element to be visible
   * @param locator - Element locator
   * @param timeout - Maximum wait time
   */
  async waitForElement(locator: Locator, timeout: number = 10000): Promise<void> {
    await locator.waitFor({ state: 'visible', timeout });
  }

  /**
   * Get page title
   * @returns Page title
   */
  async getPageTitle(): Promise<string> {
    const title = await this.page.title();
    logger.info(`Page title: ${title}`);
    return title;
  }

  /**
   * Get current URL
   * @returns Current page URL
   */
  async getCurrentUrl(): Promise<string> {
    const url = this.page.url();
    logger.info(`Current URL: ${url}`);
    return url;
  }

  /**
   * Take screenshot
   * @param name - Screenshot name
   */
  async screenshot(name: string): Promise<void> {
    await takeScreenshot(this.page, name);
  }

  /**
   * Reload current page
   */
  async reload(): Promise<void> {
    await this.page.reload();
    await waitForPageLoad(this.page);
    logger.info('Page reloaded');
  }

  /**
   * Go back in browser history
   */
  async goBack(): Promise<void> {
    await this.page.goBack();
    await waitForPageLoad(this.page);
    logger.info('Navigated back');
  }

  /**
   * Press keyboard key
   * @param key - Key to press
   */
  async pressKey(key: string): Promise<void> {
    await this.page.keyboard.press(key);
    logger.info(`Pressed key: ${key}`);
  }
}
