/**
 * Base Page Object Model
 * Contains common methods used by all page objects
 */

const logger = require('../utils/logger');
const helpers = require('../utils/helpers');
const screenshot = require('../utils/screenshot');

class BasePage {
  constructor(page) {
    this.page = page;
  }

  /**
   * Navigate to a URL
   */
  async navigate(url) {
    logger.step(`Navigating to: ${url}`);
    await this.page.goto(url, { waitUntil: 'networkidle' });
    await this.page.waitForLoadState('domcontentloaded');
  }

  /**
   * Get page title
   */
  async getTitle() {
    return await this.page.title();
  }

  /**
   * Get current URL
   */
  async getCurrentURL() {
    return this.page.url();
  }

  /**
   * Click element with logging
   */
  async click(selector, description = '') {
    logger.step(`Clicking: ${description || selector}`);
    await helpers.safeClick(this.page, selector);
  }

  /**
   * Fill input with logging
   */
  async fill(selector, text, description = '') {
    logger.step(`Filling ${description || selector} with: ${text}`);
    await helpers.safeFill(this.page, selector, text);
  }

  /**
   * Get text content
   */
  async getText(selector) {
    return await helpers.getElementText(this.page, selector);
  }

  /**
   * Check if element is visible
   */
  async isVisible(selector, timeout = 5000) {
    try {
      await this.page.waitForSelector(selector, { 
        state: 'visible', 
        timeout 
      });
      return true;
    } catch {
      return false;
    }
  }

  /**
   * Wait for element
   */
  async waitForElement(selector, timeout = 10000) {
    await helpers.waitForElement(this.page, selector, timeout);
  }

  /**
   * Take screenshot
   */
  async takeScreenshot(testName, step) {
    return await screenshot.capture(this.page, testName, step);
  }

  /**
   * Wait for navigation
   */
  async waitForNavigation() {
    await helpers.waitForPageLoad(this.page);
  }

  /**
   * Check URL contains text
   */
  async urlContains(text) {
    const url = await this.getCurrentURL();
    return url.includes(text);
  }

  /**
   * Verify page loaded successfully
   */
  async verifyPageLoaded(expectedUrlPart, timeout = 10000) {
    await this.page.waitForLoadState('networkidle', { timeout });
    const currentUrl = await this.getCurrentURL();
    logger.assertion(`Page URL contains "${expectedUrlPart}"`, 
                     currentUrl.includes(expectedUrlPart));
    return currentUrl.includes(expectedUrlPart);
  }
}

module.exports = BasePage;
