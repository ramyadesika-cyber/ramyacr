import { Page, Locator } from '@playwright/test';
import { BasePage } from './BasePage';
import logger from '../utils/logger';

/**
 * Login Page Object Model
 * Contains all elements and methods for Login page
 */
export class LoginPage extends BasePage {
  // Locators
  readonly usernameInput: Locator;
  readonly passwordInput: Locator;
  readonly loginButton: Locator;
  readonly errorMessage: Locator;
  readonly loginFormTitle: Locator;

  constructor(page: Page) {
    super(page);
    
    // Initialize locators
    this.usernameInput = page.locator('input[name="username"], input[id="username"], input[placeholder*="username" i]');
    this.passwordInput = page.locator('input[name="password"], input[id="password"], input[type="password"]');
    this.loginButton = page.locator('button[type="submit"], button:has-text("Login"), input[type="submit"]');
    this.errorMessage = page.locator('.error, .alert-danger, [class*="error"], [class*="alert"]');
    this.loginFormTitle = page.locator('h1, h2, h3, .login-title, [class*="title"]').first();
  }

  /**
   * Navigate to Login page
   */
  async goto(): Promise<void> {
    logger.info('Navigating to Login page');
    await this.navigateTo('/views/admin/login.php');
  }

  /**
   * Enter username
   * @param username - Username to enter
   */
  async enterUsername(username: string): Promise<void> {
    logger.info(`Entering username: ${username}`);
    await this.fill(this.usernameInput, username);
  }

  /**
   * Enter password
   * @param password - Password to enter
   */
  async enterPassword(password: string): Promise<void> {
    logger.info('Entering password');
    await this.fill(this.passwordInput, password);
  }

  /**
   * Click login button
   */
  async clickLogin(): Promise<void> {
    logger.info('Clicking login button');
    await this.click(this.loginButton);
  }

  /**
   * Complete login flow
   * @param username - Username
   * @param password - Password
   */
  async login(username: string, password: string): Promise<void> {
    logger.info(`Attempting login with username: ${username}`);
    await this.enterUsername(username);
    await this.enterPassword(password);
    await this.clickLogin();
    
    // Wait for navigation or error
    await this.page.waitForLoadState('networkidle', { timeout: 10000 }).catch(() => {
      logger.warn('Navigation timeout, checking for error message');
    });
  }

  /**
   * Check if error message is displayed
   * @returns True if error message visible
   */
  async isErrorMessageDisplayed(): Promise<boolean> {
    return await this.isVisible(this.errorMessage);
  }

  /**
   * Get error message text
   * @returns Error message text
   */
  async getErrorMessage(): Promise<string> {
    if (await this.isErrorMessageDisplayed()) {
      return await this.getText(this.errorMessage);
    }
    return '';
  }

  /**
   * Check if username field is empty
   * @returns True if empty
   */
  async isUsernameEmpty(): Promise<boolean> {
    const value = await this.usernameInput.inputValue();
    return value === '';
  }

  /**
   * Check if password field is empty
   * @returns True if empty
   */
  async isPasswordEmpty(): Promise<boolean> {
    const value = await this.passwordInput.inputValue();
    return value === '';
  }

  /**
   * Clear username field
   */
  async clearUsername(): Promise<void> {
    await this.usernameInput.clear();
    logger.info('Username field cleared');
  }

  /**
   * Clear password field
   */
  async clearPassword(): Promise<void> {
    await this.passwordInput.clear();
    logger.info('Password field cleared');
  }

  /**
   * Verify login page is loaded
   * @returns True if login page elements are visible
   */
  async isLoginPageLoaded(): Promise<boolean> {
    try {
      await this.waitForElement(this.usernameInput);
      await this.waitForElement(this.passwordInput);
      await this.waitForElement(this.loginButton);
      logger.info('Login page loaded successfully');
      return true;
    } catch {
      logger.error('Login page failed to load');
      return false;
    }
  }

  /**
   * Get login form title
   * @returns Form title text
   */
  async getFormTitle(): Promise<string> {
    return await this.getText(this.loginFormTitle);
  }
}
