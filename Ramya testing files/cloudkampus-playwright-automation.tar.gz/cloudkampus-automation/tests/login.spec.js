/**
 * Login Test Suite
 * Test Cases: CK_LOGIN_001, CK_LOGIN_002
 * Phase 1: Critical Path Testing
 */

const { test, expect } = require('@playwright/test');
const LoginPage = require('../pages/LoginPage');
const logger = require('../utils/logger');
const screenshot = require('../utils/screenshot');
const testData = require('../data/login-data.json');

// Test suite setup
test.describe('Login Module - Critical Path Tests', () => {
  let loginPage;

  // Before each test
  test.beforeEach(async ({ page }) => {
    loginPage = new LoginPage(page);
    await loginPage.navigateToLogin();
  });

  /**
   * Test Case: CK_LOGIN_001
   * Title: Login with valid credentials
   * Priority: Critical
   */
  test('CK_LOGIN_001: Login with valid credentials', async ({ page }) => {
    const testId = 'CK_LOGIN_001';
    logger.testStart(testId);

    try {
      // Test Data
      const { username, password } = testData.validUser;

      // Step 1: Verify login page loaded
      logger.step('Step 1: Verify login page is displayed');
      await expect(page).toHaveURL(/login\.php/);
      const formDisplayed = await loginPage.verifyLoginFormDisplayed();
      expect(formDisplayed).toBeTruthy();

      // Screenshot: Login page
      await loginPage.takeScreenshot(testId, 'login_page_loaded');

      // Step 2: Enter credentials
      logger.step('Step 2: Enter valid credentials');
      await loginPage.enterUsername(username);
      await loginPage.enterPassword(password);

      // Screenshot: Credentials entered
      await loginPage.takeScreenshot(testId, 'credentials_entered');

      // Step 3: Click login button
      logger.step('Step 3: Click Login button');
      await loginPage.clickLoginButton();

      // Step 4: Verify successful login
      logger.step('Step 4: Verify successful login and dashboard navigation');
      await page.waitForTimeout(2000); // Wait for navigation
      
      // Verify URL changed to dashboard
      await expect(page).toHaveURL(/dashboard\.php/, { timeout: 10000 });
      
      // Verify dashboard page loaded
      const loginSuccess = await loginPage.verifySuccessfulLogin();
      expect(loginSuccess).toBeTruthy();

      // Screenshot: Dashboard after login
      await loginPage.takeScreenshot(testId, 'dashboard_loaded');

      // Step 5: Verify no console errors
      logger.step('Step 5: Verify no JavaScript errors');
      const errors = [];
      page.on('pageerror', error => errors.push(error));
      expect(errors.length).toBe(0);

      logger.testEnd(testId, 'PASS');

    } catch (error) {
      logger.error(`Test ${testId} failed: ${error.message}`);
      await screenshot.captureOnFailure(page, test.info());
      logger.testEnd(testId, 'FAIL');
      throw error;
    }
  });

  /**
   * Test Case: CK_LOGIN_002  
   * Title: Session management - Logout functionality
   * Priority: High
   */
  test('CK_LOGIN_002: Logout and verify session termination', async ({ page }) => {
    const testId = 'CK_LOGIN_002';
    logger.testStart(testId);

    try {
      const { username, password } = testData.validUser;

      // Step 1: Login first
      logger.step('Step 1: Login with valid credentials');
      await loginPage.login(username, password);
      await page.waitForTimeout(2000);
      
      // Verify logged in
      await expect(page).toHaveURL(/dashboard\.php/);
      await loginPage.takeScreenshot(testId, 'logged_in');

      // Step 2: Locate and click logout
      logger.step('Step 2: Click Logout button');
      
      // Common logout button selectors (adjust based on actual app)
      const logoutSelectors = [
        'a:has-text("Logout")',
        'button:has-text("Logout")',
        '.logout',
        '#logout',
        'a[href*="logout"]'
      ];

      let logoutClicked = false;
      for (const selector of logoutSelectors) {
        try {
          if (await page.isVisible(selector, { timeout: 2000 })) {
            await page.click(selector);
            logoutClicked = true;
            logger.step(`Clicked logout using selector: ${selector}`);
            break;
          }
        } catch (e) {
          continue;
        }
      }

      expect(logoutClicked).toBeTruthy();
      await page.waitForTimeout(2000);

      // Step 3: Verify redirected to login page
      logger.step('Step 3: Verify redirected to login page');
      await expect(page).toHaveURL(/login\.php/, { timeout: 10000 });
      await loginPage.takeScreenshot(testId, 'after_logout');

      // Step 4: Try to access dashboard using back button
      logger.step('Step 4: Press browser back button and verify no access');
      await page.goBack();
      await page.waitForTimeout(2000);

      // Should still be on login or redirected back to login
      const currentUrl = await loginPage.getCurrentURL();
      const sessionTerminated = currentUrl.includes('login.php');
      
      logger.assertion('Session terminated - Cannot access dashboard', sessionTerminated);
      expect(sessionTerminated).toBeTruthy();

      await loginPage.takeScreenshot(testId, 'back_button_test');

      logger.testEnd(testId, 'PASS');

    } catch (error) {
      logger.error(`Test ${testId} failed: ${error.message}`);
      await screenshot.captureOnFailure(page, test.info());
      logger.testEnd(testId, 'FAIL');
      throw error;
    }
  });

  /**
   * Additional Test: Verify login form elements
   * This can be enabled/disabled as needed
   */
  test.skip('Verify login form elements are displayed', async ({ page }) => {
    logger.testStart('VERIFY_FORM_ELEMENTS');

    const formDisplayed = await loginPage.verifyLoginFormDisplayed();
    expect(formDisplayed).toBeTruthy();

    const passwordMasked = await loginPage.isPasswordMasked();
    expect(passwordMasked).toBeTruthy();

    logger.testEnd('VERIFY_FORM_ELEMENTS', 'PASS');
  });
});
