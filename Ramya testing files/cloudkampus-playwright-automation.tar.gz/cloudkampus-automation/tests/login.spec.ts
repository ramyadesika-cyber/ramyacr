import { test, expect } from '@playwright/test';
import { LoginPage } from '../pages/LoginPage';
import { DashboardPage } from '../pages/DashboardPage';
import { getUserCredentials, getTestData } from '../utils/testData';
import logger from '../utils/logger';

/**
 * Login Module - Test Suite
 * Sprint 1: Complete login functionality automation
 * 
 * Test Coverage:
 * - CK_LOGIN_001: Valid login flow
 * - CK_LOGIN_002: Logout and session management
 */

test.describe('Login Module - Critical Path Tests', () => {
  let loginPage: LoginPage;
  let dashboardPage: DashboardPage;

  test.beforeEach(async ({ page }) => {
    // Initialize page objects
    loginPage = new LoginPage(page);
    dashboardPage = new DashboardPage(page);
    
    // Navigate to login page before each test
    await loginPage.goto();
    
    logger.info('Test setup completed');
  });

  test.afterEach(async ({ page }, testInfo) => {
    // Take screenshot on failure
    if (testInfo.status !== testInfo.expectedStatus) {
      await page.screenshot({ 
        path: `screenshots/failure-${testInfo.title}-${Date.now()}.png`,
        fullPage: true 
      });
      logger.error(`Test failed: ${testInfo.title}`);
    }
  });

  /**
   * Test Case: CK_LOGIN_001
   * Login with valid credentials
   */
  test('CK_LOGIN_001: Should login successfully with valid credentials', async ({ page }) => {
    test.info().annotations.push({
      type: 'Test Case ID',
      description: 'CK_LOGIN_001'
    });

    // Get test data
    const validUser = getUserCredentials('validUser');
    const testData = getTestData('loginPage');

    // Step 1: Verify login page is loaded
    const isLoaded = await loginPage.isLoginPageLoaded();
    expect(isLoaded).toBeTruthy();
    logger.info('Login page loaded successfully');

    // Step 2: Enter valid credentials
    await loginPage.enterUsername(validUser.username);
    await loginPage.enterPassword(validUser.password);
    logger.info('Credentials entered');

    // Step 3: Click login button
    await loginPage.clickLogin();
    logger.info('Login button clicked');

    // Step 4: Verify successful login and redirection to dashboard
    await page.waitForURL('**/dashboard.php', { timeout: 10000 });
    const isDashboardLoaded = await dashboardPage.isDashboardLoaded();
    expect(isDashboardLoaded).toBeTruthy();
    logger.info('✓ Login successful - Dashboard loaded');

    // Step 5: Verify dashboard URL
    const currentUrl = await dashboardPage.getCurrentUrl();
    expect(currentUrl).toContain('dashboard.php');

    // Step 6: Verify dashboard title or user profile visible
    const isUserLoggedIn = await dashboardPage.isUserLoggedIn();
    expect(isUserLoggedIn).toBeTruthy();

    logger.info('✓ Test CK_LOGIN_001 passed');
  });

  /**
   * Test Case: CK_LOGIN_002
   * Session management - Logout functionality
   */
  test('CK_LOGIN_002: Should logout successfully and prevent back button access', async ({ page }) => {
    test.info().annotations.push({
      type: 'Test Case ID',
      description: 'CK_LOGIN_002'
    });

    const validUser = getUserCredentials('validUser');

    // Step 1: Login first
    await loginPage.login(validUser.username, validUser.password);
    await page.waitForURL('**/dashboard.php', { timeout: 10000 });
    
    const isDashboardLoaded = await dashboardPage.isDashboardLoaded();
    expect(isDashboardLoaded).toBeTruthy();
    logger.info('User logged in successfully');

    // Step 2: Click logout
    await dashboardPage.logout();
    logger.info('Logout clicked');

    // Step 3: Verify redirected to login page
    await page.waitForURL('**/login.php', { timeout: 10000 });
    const isLoginPageLoaded = await loginPage.isLoginPageLoaded();
    expect(isLoginPageLoaded).toBeTruthy();
    logger.info('Redirected to login page after logout');

    // Step 4: Try to navigate back using browser back button
    await page.goBack();
    await page.waitForLoadState('networkidle');

    // Step 5: Verify still on login page or redirected to login
    // (Session should be terminated, cannot access dashboard)
    const currentUrl = await page.url();
    const isStillOnLoginOrRedirected = 
      currentUrl.includes('login.php') || 
      !currentUrl.includes('dashboard.php');
    
    expect(isStillOnLoginOrRedirected).toBeTruthy();
    logger.info('✓ Session terminated - Cannot access dashboard after logout');

    logger.info('✓ Test CK_LOGIN_002 passed');
  });

  /**
   * Additional Test Scenarios for comprehensive coverage
   */

  test('Should display login page elements correctly', async () => {
    // Verify all login page elements are visible
    await expect(loginPage.usernameInput).toBeVisible();
    await expect(loginPage.passwordInput).toBeVisible();
    await expect(loginPage.loginButton).toBeVisible();
    
    logger.info('✓ All login page elements are visible');
  });

  test('Should allow clearing and re-entering credentials', async () => {
    const validUser = getUserCredentials('validUser');

    // Enter credentials
    await loginPage.enterUsername('testuser');
    await loginPage.enterPassword('testpass');

    // Clear fields
    await loginPage.clearUsername();
    await loginPage.clearPassword();

    // Verify fields are empty
    expect(await loginPage.isUsernameEmpty()).toBeTruthy();
    expect(await loginPage.isPasswordEmpty()).toBeTruthy();

    // Re-enter correct credentials
    await loginPage.login(validUser.username, validUser.password);
    
    // Verify successful login
    await expect(dashboardPage.dashboardTitle).toBeVisible({ timeout: 10000 });
    
    logger.info('✓ Credentials can be cleared and re-entered');
  });

  test('Should handle page reload during login', async () => {
    const validUser = getUserCredentials('validUser');

    // Enter credentials
    await loginPage.enterUsername(validUser.username);
    
    // Reload page
    await loginPage.reload();

    // Verify page reloaded and fields are empty
    expect(await loginPage.isUsernameEmpty()).toBeTruthy();
    
    // Login again
    await loginPage.login(validUser.username, validUser.password);
    await expect(dashboardPage.dashboardTitle).toBeVisible({ timeout: 10000 });

    logger.info('✓ Page reload handled correctly');
  });

  test('Should maintain session across page refresh on dashboard', async ({ page }) => {
    const validUser = getUserCredentials('validUser');

    // Login
    await loginPage.login(validUser.username, validUser.password);
    await page.waitForURL('**/dashboard.php', { timeout: 10000 });

    // Refresh dashboard page
    await page.reload();
    await page.waitForLoadState('networkidle');

    // Verify still on dashboard (session maintained)
    const isDashboardLoaded = await dashboardPage.isDashboardLoaded();
    expect(isDashboardLoaded).toBeTruthy();

    logger.info('✓ Session maintained after page refresh');
  });
});

/**
 * Login Module - Data-Driven Tests
 * Multiple test data iterations
 */
test.describe('Login Module - Data-Driven Tests', () => {
  let loginPage: LoginPage;

  test.beforeEach(async ({ page }) => {
    loginPage = new LoginPage(page);
    await loginPage.goto();
  });

  // Test with multiple valid user scenarios
  const testUsers = [
    { username: 'ramya', password: 'Aspire#2025', description: 'Admin user' }
  ];

  for (const user of testUsers) {
    test(`Should login with ${user.description}`, async ({ page }) => {
      const dashboardPage = new DashboardPage(page);

      await loginPage.login(user.username, user.password);
      await page.waitForURL('**/dashboard.php', { timeout: 10000 });

      const isDashboardLoaded = await dashboardPage.isDashboardLoaded();
      expect(isDashboardLoaded).toBeTruthy();

      logger.info(`✓ Login successful for ${user.description}`);
    });
  }
});
