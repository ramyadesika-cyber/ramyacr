module.exports = {
  baseURL: 'https://learntest.xdemo.in',
  timeout: 30000,
  retries: 0,
  headless: false,
  slowMo: 100
};
