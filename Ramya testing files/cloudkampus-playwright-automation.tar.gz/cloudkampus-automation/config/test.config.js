module.exports = {
  baseURL: 'https://learntest.xdemo.in',
  timeout: 60000,
  retries: 2,
  headless: true,
  slowMo: 0
};
