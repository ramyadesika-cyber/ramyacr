# Quick Setup Guide - CloudKampus Automation

## 🎯 Goal
Get the automation framework up and running on your machine in 15 minutes.

## ✅ Prerequisites Check

Before starting, ensure you have:

```bash
# Check Node.js (should be v16+)
node --version

# Check npm (should be v8+)
npm --version

# Check Git
git --version
```

If any are missing, install from:
- Node.js: https://nodejs.org/ (Download LTS version)
- Git: https://git-scm.com/downloads

## 📥 Step 1: Get the Code

### Option A: If repository exists on GitHub/GitLab

```bash
# Clone the repository
git clone <your-repo-url>
cd cloudkampus-automation
```

### Option B: If starting fresh

```bash
# Create directory and initialize
mkdir cloudkampus-automation
cd cloudkampus-automation
git init

# Copy all framework files to this directory
```

## 📦 Step 2: Install Dependencies

```bash
# Install all npm packages
npm install

# This installs:
# - @playwright/test
# - winston (logger)
# - dotenv
# - allure-playwright (reporter)
```

## 🌐 Step 3: Install Browsers

```bash
# Install all browsers (Chromium, Firefox, WebKit)
npm run install:browsers

# OR install specific browser only
npx playwright install chromium
```

This downloads browser binaries (~300MB per browser).

## ⚙️ Step 4: Verify Installation

```bash
# Check Playwright version
npx playwright --version

# Should output: Version 1.40.0 or higher
```

## 🎬 Step 5: Run Your First Test

```bash
# Run all tests (headless)
npm test

# Run in headed mode (see browser)
npm run test:headed

# Run specific test file
npm run test:login
```

## 📊 Step 6: View Report

```bash
# After test run, view HTML report
npm run report
```

Browser will open with test results automatically.

## ✅ Verification Checklist

After setup, verify:

- [ ] `node_modules/` directory exists (packages installed)
- [ ] `~/.cache/ms-playwright/` has browsers (browsers installed)
- [ ] Tests execute without errors
- [ ] Report generates and opens
- [ ] Logs appear in `logs/` directory
- [ ] Screenshots captured on failure

## 🐛 Common Setup Issues

### Issue 1: `npm install` fails

**Solution:**
```bash
# Clear npm cache
npm cache clean --force

# Try again
npm install
```

### Issue 2: Browser installation fails

**Solution:**
```bash
# Install with sudo (Linux/Mac)
sudo npx playwright install --with-deps

# Or use --force flag
npx playwright install --force
```

### Issue 3: Tests fail with "Cannot find module"

**Solution:**
```bash
# Reinstall dependencies
rm -rf node_modules
npm install
```

### Issue 4: Permission errors on Linux/Mac

**Solution:**
```bash
# Fix permissions
sudo chown -R $USER:$USER ~/.cache/ms-playwright
```

## 🎓 Next Steps

Once setup is complete:

1. **Read the README.md** - Full documentation
2. **Review test files** - Understand test structure
3. **Check Page Objects** - See POM pattern
4. **Modify test data** - Update `data/login-data.json`
5. **Run tests** - Practice different commands

## 📁 Directory Structure After Setup

```
cloudkampus-automation/
├── node_modules/          ✅ Installed packages
├── .github/               ✅ CI/CD configs
├── config/                ✅ Environment configs
├── data/                  ✅ Test data
├── pages/                 ✅ Page Objects
├── tests/                 ✅ Test specs
├── utils/                 ✅ Utilities
├── logs/                  📝 Created on first run
├── reports/               📝 Created on first run
├── screenshots/           📝 Created on failures
└── package.json           ✅ Installed
```

## 🚀 Quick Command Reference

```bash
# Run tests
npm test                    # All tests, headless
npm run test:headed         # All tests, headed
npm run test:login          # Login tests only
npm run test:debug          # Debug mode

# View reports
npm run report              # Open HTML report

# Browsers
npm run install:browsers    # Install all browsers
npx playwright install chromium  # Install Chromium only
```

## ✨ You're Ready!

Framework is now set up and ready for:
- Writing new tests
- Running regression suites
- CI/CD integration
- Team collaboration

**Need help?** Check README.md or contact QA team.

---

Setup time: ~15 minutes  
Last updated: December 12, 2025
